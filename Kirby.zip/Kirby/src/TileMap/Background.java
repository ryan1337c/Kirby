package TileMap;

import java.awt.Graphics2D;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Game.GamePanel;

public class Background {
	
	private BufferedImage image;
	
	private double x;
	private double y;
	private double dx;
	private double dy;
	
	private double moveScaleX;
	private double moveScaleY;
	
	private int width;
	private int height;
	
	public Background (String s, double msx, double msy) {
		
		try {
				image = ImageIO.read(getClass().getResourceAsStream(s));
				moveScaleX = msx;
				moveScaleY = msy;
				
				width = image.getWidth();
				height = image.getHeight();
				
			}
		catch(Exception e) {
				e.printStackTrace();
		}
	}
	

	public void setPosition (double x, double y) {
		// we don't want to draw x and y points off the screen so % GamePanel.WIDTH/HEIGHT keeps it within the screen
		this.x = (x * moveScaleX) % GamePanel.WIDTH;
		this.y = (y * moveScaleY) % GamePanel.HEIGHT;
	}
	
	public void setVector (double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	public void update() {
		x += dx;
		while(x <= -width) x += width;
		while(x >= width) x -= width;
		y += dy;
		while(y <= -height) y += height;
		while(y >= height) y -= height;
	}
	
	public void draw (Graphics2D g) {
		g.drawImage(image, (int)x, (int)y, GamePanel.WIDTH, GamePanel.HEIGHT, null);
		// Makes sure background stays in the frame
		
		if (x < 0) {
			x += GamePanel.WIDTH;
			if (x == 0) x = 0;
			g.drawImage(image, (int)x, (int)y, null);
			
		}
		if (x > 0) {
			g.drawImage(image, (int)x - GamePanel.WIDTH, (int) y, null);
		}
		if(y < 0) {
			g.drawImage(image, (int)x, (int)y + GamePanel.HEIGHT, null);
		}
		if(y > 0) {
			g.drawImage(image, (int)x, (int)y - GamePanel.HEIGHT, null);
		}
		
	}
	
	public double gety() {
		return y;
	}

}
