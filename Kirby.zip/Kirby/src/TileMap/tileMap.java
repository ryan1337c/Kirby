package TileMap;

import java.awt.*;


import java.awt.image.*;
import java.io.*;
import java.util.HashMap;

import javax.imageio.ImageIO;
import Entity.Animation;
import Entity.MapObject;
import Game.GamePanel;
public class tileMap {
	
	// level
	private int level;
	
	// animation
	private HashMap <String, Animation> animation = new HashMap <String, Animation>();
	private HashMap <String, BufferedImage []> sprites = new HashMap <String, BufferedImage[]>();
	
	// position 
	private double x;
	private double y;
	
	// bounds
	private int xmax;
	private int xmin;
	private int ymax;
	private int ymin;
	
	private double tween;
	
	// map
	private int[][] map;
	private int[][] map2;
	private int tileSize;
	private int numRows;
	private int numCols;
	
	// in pixels
	private int width;
	private int height;
	
	// tileset
	private BufferedImage tileset;
	private int numTileAcross;
	private Tile[][] tiles;
	
	// drawing tiles on screen
	private int rowOffSet;
	private int colOffSet;
	private int numRowsToDraw;
	private int numColsToDraw;
	
	// timer for blocks
	private int eventCount;
	
	// effects
	private boolean shaking;
	private int intensity;
	
	public tileMap (int tileSize) {
		this.tileSize = tileSize;
		numRowsToDraw = GamePanel.HEIGHT / tileSize + 2;	
		numColsToDraw = GamePanel.WIDTH / tileSize + 2;
		tween = 0.07;
	}
	
	public void loadTiles (String s) {
		try {
			// get entire sprite sheet
			tileset = ImageIO.read(getClass().getResourceAsStream(s));
			numTileAcross = tileset.getWidth() / tileSize;
			if (level == 1) tiles = new Tile[2][numTileAcross];
			if (level == 2) tiles = new Tile[4][numTileAcross];
			
			// importing entire sprite sheet into tiles[][] array
			BufferedImage subimage;
			for (int col = 0; col < numTileAcross; col++) {
				if (level == 1) {
					subimage = tileset.getSubimage(col * tileSize, 0, tileSize, tileSize);
					tiles[0][col] = new Tile (subimage, Tile.NORMAL);
					subimage = tileset.getSubimage(col * tileSize, tileSize, tileSize, tileSize);
					if (col == numTileAcross - 1) tiles[1][col] = new Tile (subimage, Tile.NORMAL);
					else tiles[1][col] = new Tile (subimage, Tile.BLOCKED);
				}
				else if (level == 2) {
					subimage = tileset.getSubimage(col * tileSize, 0, tileSize, tileSize);
					tiles[0][col] = new Tile (subimage, Tile.NORMAL);
					
					
					subimage = tileset.getSubimage(col * tileSize, tileSize, tileSize, tileSize);
					if (col == numTileAcross - 1) tiles[1][col] = new Tile (subimage, Tile.NORMAL);
					else if (col == 5 || col == 4) tiles[1][col] = new Tile (subimage, Tile.WATER);
					else if (col == 6) {
						subimage = tileset.getSubimage(col * tileSize, tileSize + 10 , tileSize - 10, tileSize - 10);
						tiles[1][col] = new Tile (subimage, Tile.BLOCKED);
					}
					else if (col == 14 || col == 15) tiles[1][col] = new Tile (subimage, Tile.NORMAL);
					else tiles[1][col] = new Tile (subimage, Tile.BLOCKED);
					
					subimage = tileset.getSubimage(col * tileSize, tileSize * 2, tileSize, tileSize);
					if (col == 14 || col == 15) {
						tiles[2][col] = new Tile (subimage, Tile.NORMAL);
					}
					else if (col == 1 || col == 2 || col == 3 || col == 4 || col == 5 || col == 6 || col == 7 || col == 8 || col == 9) {
						tiles[2][col] = new Tile (subimage, Tile.BLOCKED);
					}
					else {
						tiles[2][col] = new Tile (subimage, Tile.WATER);
					}
					
					subimage = tileset.getSubimage(col * tileSize, tileSize * 3, tileSize, tileSize);
					if (col == 14 || col == 15) {
						tiles[3][col] = new Tile (subimage, Tile.NORMAL);
					}
					else {
						tiles[3][col] = new Tile (subimage, Tile.BLOCKED);
					}
						
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void loadMap (String s) {
		try {
			InputStream in = getClass().getResourceAsStream(s);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			numCols = Integer.parseInt(br.readLine());
			numRows = Integer.parseInt(br.readLine());
			
			map = new int [numRows][numCols];
			width = numCols * tileSize;
			height = numRows * tileSize;
			xmin = GamePanel.WIDTH - width;
			xmax = 0;
			ymin = GamePanel.HEIGHT - height;
			ymax = 0;
			
			// load map
			load(numRows, numCols, br, map);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void loadMap2 (String s) {
		try {
			InputStream in = getClass().getResourceAsStream(s);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			numCols = Integer.parseInt(br.readLine());
			numRows = Integer.parseInt(br.readLine());
			map2 = new int [numRows][numCols];
			// loads map
			load(numRows, numCols, br, map2); 
		}
		catch (Exception e) {} 
	}
	
	private void load(int r, int c, BufferedReader br, int[][] map) {
		try {
			// Note \\s+ means white spaces in files
			String delims = "\\s+";
			for (int row = 0; row < numRows; row++) {
				String line = br.readLine();
				String[] tokens = line.split(delims);
				for (int col = 0; col < numCols; col++) {
					try {
						map[row][col] = Integer.parseInt(tokens[col]);
					} catch (Exception e) {
					}
				}
			}	
		}
		catch (Exception e) {}
	}

	public int getTileSize() {
		return tileSize;
	}
	
	public double getx() {
		return x;
	}
	
	public double gety() {
		return y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public int getTile(int r, int c) {
		return map[r][c];
	}
	
	public boolean isShaking() {
		return shaking;
	}
	
	public void setShaking(boolean b, int i) {
		shaking = b;
		intensity = i;
	}
	
	public void setTween(double a) {
		tween = a;
	}
	
	public void setLevel(int d) {
		level = d;
	}
	
	public void setBound(int i1, int i2, int i3, int i4) {
		xmin = GamePanel.WIDTH - i1;
		ymin = GamePanel.HEIGHT - i2;
		xmax = i3;
		ymax = i4;
	}
	
	public void setMaxBound(int i1, int i2) {
		xmax = i1;
		ymax = i2;
	}
	
	public void update() {
		if (shaking) {
			this.x += Math.random() * intensity - intensity / 2;
			this.y += Math.random() * intensity - intensity / 2;
		}
	}
	public void replaceTile (int newTile, int oldTile) {
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map[0].length; j++) {
				if (map[i][j] == oldTile) map[i][j] = newTile;
			}
		}
	}
	
	public void loadAnimation(String key, String path, int numSprites, int delay) {
		int width = 30;
		int height = 30;
		try {
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream(path));
			// load sprite
				BufferedImage[] bi = new BufferedImage[numSprites];
				for (int j = 0; j < numSprites; j++) {
					bi[j] = spritesheet.getSubimage(j * width, 0, width, height);
				}

				animation.put(key, new Animation());
				animation.get(key).setFrames(bi);
				animation.get(key).setDelay(delay);
		}	
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int getType(int row, int col) {
		int rc = map[row][col];
		int r = rc / numTileAcross;
		int c = rc % numTileAcross;
		return tiles[r][c].getType();
	}
	
	// camera position 
	public void setPosition(double x, double y) {
		
		// smoothly moves camera when scrolling through map
		this.x += (x - this.x) * tween;
		this.y += (y - this.y) * tween;	
		
		fixBounds();
		
		// where to start drawing
		colOffSet = (int)-this.x / tileSize;
		rowOffSet = (int)-this.y / tileSize;
		
	}
	
	public void fixBounds() {
		if (x < xmin) x = xmin;
		if (x > xmax) x = xmax;
		if (y < ymin) y = ymin;
		if (y > ymax) y = ymax;
	}
	
	public void draw(Graphics2D g) {
		for (int row = rowOffSet; row < rowOffSet + numRowsToDraw; row++) {

			if (row >= numRows)
				break;

			for (int col = colOffSet; col < colOffSet + numColsToDraw; col++) {

				if (col >= numCols)
					break;

				int rc = map[row][col];
				int r = rc / numTileAcross;
				int c = rc % numTileAcross;
				// checks if button has been pressed
				if (MapObject.buttonPressed && map[row][col] == 47) {
					replaceTile(38, 16);
					eventCount = 0;
					if (animation.get("button").hasPlayedOnce() == true) {
						MapObject.buttonPressed = false;
						MapObject.fillBlocks = true;
						// resets animation
						animation.get("button").setCycle(false);
					} else {
						g.drawImage(animation.get("button").getImage(), (int) x + col * tileSize,
								(int) y + row * tileSize, null);
						animation.get("button").update();
					}
				} else {
					eventCount++;
					if (eventCount >= 76000 && level == 2) {
						replaceTile(16, 38);
					}
					// Note x and y are in pixels
					g.drawImage(tiles[r][c].getImage(), (int) x + col * tileSize, (int) y + row * tileSize, null);
				}
			}
		}
	}
	
	public void drawLayer2(Graphics2D g) {
		for (int row = rowOffSet; row < rowOffSet + numRowsToDraw; row++) {

			if (row >= numRows)
				break;

			for (int col = colOffSet; col < colOffSet + numColsToDraw; col++) {

				if (col >= numCols)
					break;
				int r2 = 0;
				int c2 = 0;
				// loads seconds layer
				int rc2 = map2[row][col];
				r2 = rc2 / numTileAcross;
				c2 = rc2 % numTileAcross;
				
				// drawing seconds layer
				if (level == 2 && map2[row][col] == 42) {
					g.drawImage(animation.get("water").getImage(), (int)x + col * tileSize, (int)y + row * tileSize, null);
					animation.get("water").update();
				}
				else {
					g.drawImage(tiles[r2][c2].getImage(), (int)x + col * tileSize, (int)y + row * tileSize, null);
				}
			}
		}
	}
	
	
	

}
