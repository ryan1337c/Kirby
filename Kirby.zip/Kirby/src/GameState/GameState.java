package GameState;

import java.awt.Point;

public abstract class GameState {
	
	protected GameStateManager gsm;
	public static int level;
	// key handler
	protected boolean blockInput;
	
	// check points when player falls into void for some level
	public Point[] checkPoints;
	
	public abstract void init();
	public abstract void update();
	public abstract void draw(java.awt.Graphics2D g);
	public abstract void keyPressed(int k);
	public abstract void keyRealeased(int k);
	

}
