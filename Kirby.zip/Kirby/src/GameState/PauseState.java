package GameState;

import java.awt.Graphics2D;


import java.awt.Rectangle;
import java.awt.event.KeyEvent;


import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import Game.GamePanel;
import java.awt.AlphaComposite;
public class PauseState extends GameState{
	
	// features 
	private String[] options = {"Resume", "Retry", "Menu"};
	private Color backColor;
	private Color titleColor;
	private Font titleFont;
	private int currentChoice;
	private Graphics2D gs;
	// coordinates for transparency
	private final float ALPHA = (float) 0.06;
	
	public PauseState (GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}

	@Override
	public void init() {
		backColor = new Color (204,204,204);
		titleColor = new Color (255,105,180);
		titleFont = new Font ("Century Gothic", Font.BOLD, 28);
	}

	@Override
	public void update() {
	}

	@Override
	public void draw(Graphics2D g) {
		gs = g;
		// fading transparent background
		AlphaComposite alcom = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, ALPHA);
		gs.setComposite(alcom);
		gs.setColor(backColor);
		gs.fillRect(0, 0, GamePanel.WIDTH, GamePanel.HEIGHT);
		
		// drawing options
		gs.setFont(titleFont);
		
		for (int i = 0; i < options.length; i++) {
			if (currentChoice == i) {
				gs.setColor(Color.white);
			}
			else {
				gs.setColor(titleColor);
			}
			gs.drawString(options[i], 120, 90 + i * 40);
		}
		
	}
	
	public void select() {
		gsm.setPause(false);
		gs.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
		if (currentChoice == 0) {
		}
		if (currentChoice == 1) {
			// retry
			gsm.setState(level);
		}
		if (currentChoice == 2) {
			//menu
			gsm.setState(0);
		}
		// resets choice after picking
		currentChoice = 0;
	}
	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select();
		}
		if (k == KeyEvent.VK_UP) {
			currentChoice--;
			if (currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if (k == KeyEvent.VK_DOWN) {
			currentChoice++;
			if (currentChoice == 3) {
				currentChoice = 0;
			}
		}
		
	}

	@Override
	public void keyRealeased(int k) {
		
		
	}
}
