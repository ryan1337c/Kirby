package GameState;

import java.awt.Graphics2D;

import java.awt.event.KeyEvent;

import TileMap.Background;
import java.awt.Color;
import java.awt.Font;
public class EndScreenState extends GameState{
	
	Background endScreen;
	
	// end screen features
	private String[] options = {"Retry", "Menu"};
	private Color titleColor;
	private Font titleFont;
	private Font font;
	private int currentChoice = 0;
	
	public EndScreenState (GameStateManager gsm) {
		this.gsm = gsm;
		
		try {
			endScreen = new Background("/Resources/Backgrounds/GameOver.png", 0, 0);
			endScreen.setVector(0,0);
			titleColor = new Color (255, 0, 0);
			titleFont = new Font("Century Gothic", Font.BOLD, 28);
			font = new Font ("Serif", Font.BOLD, 15);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		init();
	}
	
	public void init() {
	}
	public void update() {
		endScreen.update();
	}
	public void draw (Graphics2D g) {
		endScreen.draw(g);
		
		// draw title
		g.setColor(titleColor);
		g.setFont(titleFont);
		g.drawString("Game Over", 80, 40);
		
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
			if (currentChoice == i) {
				g.setColor(Color.WHITE);
			}
			else {
				g.setColor(Color.PINK);
			}
			g.drawString(options[i], 250, 140 + i * 15);
		}
	}
	public void select() {
		// retry level
		if (currentChoice == 0) {
			gsm.setState(level);
		}
		// Quit
		if (currentChoice == 1) {
			gsm.setState(0);
		}
	}
	public void keyRealeased(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select();
		}
		if (k == KeyEvent.VK_UP) {
			currentChoice--;
			if (currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if (k == KeyEvent.VK_DOWN) {
			currentChoice++;
			if (currentChoice == options.length) {
				currentChoice = 0;
			}
		}
	}
	public void keyPressed (int k) {
		
	}

}
