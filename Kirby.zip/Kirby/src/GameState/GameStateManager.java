package GameState;

import java.util.ArrayList;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
public class GameStateManager {
	
	private GameState[] gameStates;
	private int currentState;
	private boolean pause;
	
	public static final int NUMGAMESTATE = 4;
	public static final int MENUSTATE = 0;
	public static final int LEVEL1STATE = 1;
	public static final int LEVEL2STATE = 2;
	public static final int GAMEOVER = 3;
	
	public PauseState pauseState;
	
	// Keeps track of Menu/Play Game states
	public GameStateManager() {
		gameStates = new GameState[NUMGAMESTATE];
		pauseState = new PauseState(this);
		currentState = MENUSTATE;
		loadState(currentState);
	}
	
	private void loadState(int state) {
		if (state == MENUSTATE) {
			gameStates[state] = new MenuState(this);
		}
		else if (state == LEVEL1STATE) {
			gameStates[state] = new Level1State(this);
		}
		else if (state == GAMEOVER) {
			gameStates[state] = new EndScreenState(this);
		}
		else if (state == LEVEL2STATE) {
			gameStates[state] = new Level2State(this);
		}
	}
	
	private void unloadState(int state) {
		gameStates[state] = null;
	}
	
	public void setPause(boolean b) {
		pause = b;
	}
	
	public boolean getPause() { return pause;}
	
	// Initializes game state
	public void setState(int state) {
		unloadState(currentState);
		currentState = state;
		loadState(state);
	}
	
	public void update () {
		if (!pause && gameStates[currentState] != null) {
			gameStates[currentState].update();
		}
	}
	
	public void draw (java.awt.Graphics2D g) {
		if (pause) {
			pauseState.draw(g);
		}
		else if (gameStates[currentState] != null){
			gameStates[currentState].draw(g);
		}
	}

	public void keyPressed (int k) {
		if (pause) {
			pauseState.keyPressed(k);
		}
		else if (gameStates[currentState] != null) {
			gameStates[currentState].keyPressed(k);
		}
	}
	
	public void keyReleased (int k) {
		try {
			gameStates[currentState].keyRealeased(k);
		}
		catch(Exception e) {}
	}
	
	
	
	
	
	

}
