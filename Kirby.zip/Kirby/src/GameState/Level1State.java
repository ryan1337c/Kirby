package GameState;

import java.awt.event.KeyEvent;


import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Entity.*;

import java.awt.*;
import Game.GamePanel;
import TileMap.Background;
import TileMap.Tile;
import TileMap.tileMap;
import Entity.enemies.*;

public class Level1State extends GameState{
	
	private tileMap tileMap;
	private Background bg;
	
	private Player player;
	
	private HUD hud;
	
	private ArrayList <Enemy> enemies;
	private ArrayList <Explosion> explosions;
	
	
	// titles
	private Title title;
	
	// level transition
	private Teleport tp;
	private ArrayList <Rectangle> tb;
	
	// events
	private boolean eventWalk;
	private int eventCount;
	private boolean eventStart;
	private boolean eventEnd;
	
	// fireworks
	private ArrayList <Fireworks> fireworks;
	
	public Level1State (GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}

	@Override
	public void init() {
		level = 1;
		tileMap = new tileMap(30);
		tileMap.setLevel(level);
		tileMap.loadTiles("/Resources/Tilesets/grasstileset.gif");
		tileMap.loadMap("/Resources/Maps/level1-1.map");
		tileMap.setPosition(0, 0);
		// smooth scrolling
		tileMap.setTween(1.0);
				
		bg = new Background("/Resources/Backgrounds/level1Background.png", 0.1, 0.1);
		
		player = new Player(tileMap, this);
		
		// x = 2900 
		player.setPosition(100,200);
		
		hud = new HUD(player);
		
		populateEnemies();
		
		explosions = new ArrayList<Explosion>();
		
		
		// setting titles
		title = new Title("/Resources/HUD/Level1Title.png", "/Resources/HUD/Level1SubLogo.png");
		
		// setting check points
		checkPoints = new Point [3];
		populateCheckPoints();
		tp = new Teleport(player);
		
		// events
		tb = new ArrayList <Rectangle>();
		eventStart = true;
		
		// level bound
		MapObject.levelBound = GamePanel.HEIGHT;
		
		// init fireworks
		fireworks = new ArrayList <Fireworks>();
		fireworks.add(new Fireworks(3000, 100, "/Resources/Sprites/Other/yellowFireworks.png"));
		fireworks.add(new Fireworks(3100, 100, "/Resources/Sprites/Other/purpleFireworks.png"));
		fireworks.add(new Fireworks(3050, 100, "/Resources/Sprites/Other/purpleFireworks.png"));
		
	}
	
	private void populateEnemies() {
		enemies = new ArrayList<Enemy>();

		Point[] points = new Point[] {
				new Point (200, 200), new Point(860, 200), new Point(1525, 200), new Point(1680, 200), new Point (1800,200), new Point(2000, 50),
				new Point(2050, 130), new Point(2100, 200)
		};
		for (int i = 0; i < points.length; i++) {
			if (i >= 5) {
				Bronto b = new Bronto (tileMap);
				b.setPosition(points[i].x, points[i].y);
				enemies.add(b);
			}
			else {
				Coner s = new Coner(tileMap);
				s.setPosition(points[i].x, points[i].y);	
				enemies.add(s);
			 }
		}
	}
	
	private void populateCheckPoints() {
		checkPoints[0] = new Point (450, 110);
		checkPoints[1] = new Point (1110, 170);
		checkPoints[2] = new Point (1920, 110);
	}

	@Override
	public void update() {
		
		// start level transition
		if (eventStart) {
			eventStart();
		}
		
		// check if levelEnd event should start
		if (player.getx() >= 2920 && player.getx() < 2930) {
			eventWalk = true;
			blockInput = true;
		}

		// plays levelEnd walking event
		if (eventWalk) {
			
			// updates fireworks
			int fireWorksCount = 0;
			for (int i = 0; i < fireworks.size(); i++) {
				if(!fireworks.get(i).playedOnce()) {
					fireworks.get(i).update();
					break;
				}
				else {
					fireWorksCount ++;
				}
			}
			if (fireWorksCount == fireworks.size()) {
				for (int i = 0; i < fireworks.size(); i++) {
					fireworks.get(i).reset();
				}
			}
			eventWalk();
		}
		
		// checks if levelEnd transition should start
		if (eventEnd) {
			eventEnd();
		}
				
		// update player
		player.update();
		tileMap.setPosition(GamePanel.WIDTH/2 - player.getx(), GamePanel.HEIGHT/2 - player.gety());
		
		
		// set background
		bg.setPosition(tileMap.getx(), tileMap.gety());
		
		// attack enemies and getting attack detection
		player.checkAttack(enemies);
		
		// update all enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			e.update();
			if (e.isDead()) {
				enemies.remove(i);
				i--;
				explosions.add(new Explosion(e.getx(), e.gety(),"/Resources/Sprites/Enemies/explosion.gif", 6, 30, 30));
			}
		}
		
		// update Explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}
		
		// checks if player died
		if (player.dead) {
			gsm.setState(3);
		}
		
		
	}

	@Override
	public void draw(Graphics2D g) {
		
		bg.draw(g);
		
		//draw tilemap
		tileMap.draw(g);
		
		// draw player
		player.draw(g);
		
		// drawing enemies
		for (int i = 0; i < enemies.size(); i++) {
			enemies.get(i).draw(g);
		}
		
		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int)tileMap.getx(), (int)tileMap.gety());
			explosions.get(i).draw(g);
		}
		
		// draw hud
		hud.draw(g);
		
		// draw title
		title.draw(g);
		
		// draw transition boxes
		g.setColor(Color.BLACK);
		for (int i = 0; i < tb.size(); i++) {
			g.fill(tb.get(i));
		}
		
		// draw fireworks
		if (eventWalk && eventCount >= 100) {
			for (int i = 0; i < fireworks.size(); i++) {
				fireworks.get(i).setMapPosition((int)tileMap.getx(), (int)tileMap.gety());
			}
			for (int i = 0; i < fireworks.size(); i++) {
				if(!fireworks.get(i).playedOnce()) {
					fireworks.get(i).draw(g);
					break;
				}
			}
		}
		
	}

	@Override
	public void keyPressed(int k) {
		if (blockInput) return;
		if (k == KeyEvent.VK_LEFT) player.setLeft(true);
		if (k == KeyEvent.VK_RIGHT) player.setRight(true);
		if (k == KeyEvent.VK_UP) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setJabbing(true);
		}
		if (k == KeyEvent.VK_ESCAPE) {
			gsm.setPause(true);
		}
	}

	@Override
	public void keyRealeased(int k) {
		if (k == KeyEvent.VK_LEFT) player.setLeft(false);
		if (k == KeyEvent.VK_RIGHT) player.setRight(false);
		if (k == KeyEvent.VK_UP) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.count = 0;
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_F) {
			player.resetJabSFX = 0;
			player.setJabbing(false);
		}
		
	}
	
	///////// EVENTS
	
	// Level End walk event
	public void eventWalk() {
		eventCount++;
		player.stop();
		player.dontPlayJumpSound(true);
		if (player.getx() >= tileMap.getWidth() - GamePanel.WIDTH / 2) {
			tileMap.setBound(0,0, GamePanel.WIDTH - tileMap.getWidth(), 0);
		}
		if (eventCount == 1) {
			player.setPosition(2920, 200);
			player.setRight(true);
		}
		else if (eventCount < 100) {
			player.setLeft(false);
			player.setFacingRight(true);
			player.setRight(true);
		}
		else if (eventCount < 3000) {
			player.setAlwaysRight(true);
			if (eventCount == 100) {
				player.setAction(9);
				player.setVictoryDance(true);
			}
			else if (eventCount < 125) {
				player.getAnimation().setDelay(90);
				player.setSpeed(0.5);
				player.setRight(true);
			}
			else if (eventCount < 180) {
				player.setLeft(true);
			}
			else if (eventCount < 300){
				player.getAnimation().setDelay(80);
				player.setSpeed(0.5);
				player.setJumpSpeed(-15);
				player.setFallSpeed(0.40);
				player.setJumping(true);
				player.setRight(true);
				if (player.getCollision()) {
					player.getAnimation().setDelay(550);
				}
			}
			else if (eventCount < 344) {
				player.getAnimation().setDelay(80);
				player.setSpeed(2.5);
				player.setJumpSpeed(-25);
				player.setFallSpeed(0.6);
				player.setJumping(true);
				player.setLeft(true);
				if (player.getCollision()) System.out.println(eventCount);
			}
			else if (eventCount < 467) {
				player.getAnimation().setDelay(100);
				player.setSpeed(0.8);
				player.setRight(true);
			}
			else if (eventCount < 500) {
				player.getAnimation().setDelay(400);
			}
			else {
				player.setVictoryDance(false);
				eventCount = 0;
				eventWalk = false;
				eventEnd = true;
			}
		}
			
		// queues clear level music
		if (!Player.clearStageMusic && eventCount == 100) {
			Player.clearStageMusic = true;
		}
	}
	
	// Level End Teleport Event
	public void eventEnd() {
		eventCount ++;
		player.stop();
		player.setAction(7);
		if (eventCount == 1) {
			tb.clear();
			tb.add(new Rectangle(0, 0 , GamePanel.WIDTH, GamePanel.HEIGHT / 2));
			tb.add(new Rectangle(0, 0, (GamePanel.WIDTH / 2) - 40, GamePanel.HEIGHT));
			tb.add(new Rectangle(GamePanel.WIDTH, 0, GamePanel.WIDTH, GamePanel.HEIGHT));
			tb.add(new Rectangle(0, GamePanel.HEIGHT, GamePanel.WIDTH, GamePanel.HEIGHT / 2));
		}
		else if (eventCount > 1 && eventCount < 100) {
			tb.get(0).height += 2;
			tb.get(1).width += 4;
			tb.get(2).x -= 4;
			tb.get(3).y -= 1.1;
		}
		else if (eventCount == 150) {
			eventEnd = false;
			eventCount = 0;
			tb.clear();
			gsm.setState(2);
		} 
	}
	
	// Level Start Event
	public void eventStart() {
		eventCount++;
		if (eventCount == 1) {
			tb.clear();
			tb.add(new Rectangle(0, 0 , GamePanel.WIDTH, GamePanel.HEIGHT / 2));
			tb.add(new Rectangle(0, 0, GamePanel.WIDTH / 2, GamePanel.HEIGHT));
			tb.add(new Rectangle(GamePanel.WIDTH / 2 , 0, GamePanel.WIDTH / 2, GamePanel.HEIGHT));
			tb.add(new Rectangle(0, GamePanel.HEIGHT / 2, GamePanel.WIDTH, GamePanel.HEIGHT / 2));
		}
		else if (eventCount > 1 && eventCount < 60) {
			tb.get(0).height -= 4;
			tb.get(1).width -= 6;
			tb.get(2).x += 6;
			tb.get(3).y += 4;
		}
		else if (eventCount == 60) {
			eventStart = false;
			eventCount = 0;
			tb.clear();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
