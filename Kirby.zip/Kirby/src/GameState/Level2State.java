package GameState;

import java.awt.event.KeyEvent;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Entity.*;

import java.awt.*;
import Game.GamePanel;
import TileMap.Background;
import TileMap.Tile;
import TileMap.tileMap;
import Entity.enemies.*;

public class Level2State extends GameState{
	
	private tileMap tileMap;
	private Background cloud;
	private Background mountain;
	
	private Player player;
	
	// boss
	private Frosty frosty;
	private BossHUD bossHud;
	
	// player 
	private HUD hud;
	
	private ArrayList <Enemy> enemies;
	private ArrayList <Explosion> explosions;

	
	// titles
	private Title title;
	
	// level transition
	private Teleport tp;
	private ArrayList <Rectangle> tb;
	
	// projectiles
	public static HashMap <String, BufferedImage[]> projectiles = new HashMap <String, BufferedImage[]>();
	public static String[] nameProjectiles = {"ice"};
	public static int []numFrames  = {1};
	
	// events
	private boolean eventWalk;
	private int eventCount;
	private boolean eventStart;
	private boolean eventEnd;
	private boolean eventQuake;
	private boolean eventBoss;
	
	private boolean shake;
	
	// fireworks
	private ArrayList <Fireworks> fireworks;
	
	// wheels
	public static ArrayList <FerrisWheels> wheels;
	
	private Rectangle rectangle = new Rectangle (100, 130, 31, 10);
	
	public Level2State (GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}

	@Override
	public void init() {
		
		level = 2;
		tileMap = new tileMap(30);
		tileMap.setLevel(level);
		tileMap.loadTiles("/Resources/Tilesets/level2Tiles.png");
		tileMap.loadMap("/Resources/Maps/level2.txt");
		tileMap.loadMap2("/Resources/Maps/waterLevel.txt");
		tileMap.setPosition(0, 0);
		
		// init water animation
		tileMap.loadAnimation("water", "/Resources/Tilesets/waterSprite.png", 16, 100);
		tileMap.loadAnimation("button", "/Resources/Tilesets/buttonSprite.png", 4, 50);

		// smooth scrolling
		tileMap.setTween(1.0);
				
		cloud = new Background("/Resources/Backgrounds/level2Cloud.png", 0.5, 0);
		mountain = new Background("/Resources/Backgrounds/level2Mountain.png", 0.5, 0);
		
		player = new Player(tileMap, this);
		
		player.setPosition(100, 100);
		
		hud = new HUD(player);

		populateEnemies();
		
		explosions = new ArrayList<Explosion>();
		
		// setting titles
		title = new Title("/Resources/HUD/level2Title.png", "/Resources/HUD/level2Subtitle.png");
		
		// setting check points
		checkPoints = new Point [3];
		populateCheckPoints();
		tp = new Teleport(player);
		
		// events
		tb = new ArrayList <Rectangle>();
		eventStart = true;
		
		// level bound
		MapObject.levelBound = GamePanel.HEIGHT * 2;
		
		// populating ferris wheels
		populateWheels();
		
		// add projectile sprites
		try {
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Enemies/projectiles.png"));
			for (int i = 0; i < nameProjectiles.length; i++) {
				BufferedImage [] bi = new BufferedImage[numFrames[i]];
				for (int j = 0; j < numFrames[i]; j++) {
					bi[i] = spritesheet.getSubimage(i * 40, j * 40, 40, 40);
				}
				projectiles.put(nameProjectiles[i], bi);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		// init fireworks
		fireworks = new ArrayList<Fireworks>();
		fireworks.add(new Fireworks(4250, 120, "/Resources/Sprites/Other/yellowFireworks.png"));
		fireworks.add(new Fireworks(4500, 130, "/Resources/Sprites/Other/purpleFireworks.png"));
		fireworks.add(new Fireworks(4370, 120, "/Resources/Sprites/Other/purpleFireworks.png"));
		
	}
	
	private void populateEnemies() {
		//(2093, 130), (2731, 160), (2855, 190), (3114, 70), (3216, 70), (3207, 220)
		enemies = new ArrayList<Enemy>();

		Point[] points = new Point[] {
				new Point(4090, 210),
				new Point(400, 240),  new Point(500, 240), new Point(1600, 250), new Point(1800, 250), new Point(1900, 250), new Point(1400, 250), new Point (2350, 250), new Point(2600, 250),
				new Point(640, 160), new Point (700, 160), new Point(760, 160), new Point (1300, 100), new Point(2093, 130), new Point(2731, 160), new Point(2855, 190), new Point(3114, 80), new Point(3216, 80), new Point(3207,220),
				new Point (910, 160), new Point (970, 160), new Point(1030, 160), new Point(1550, 160), new Point(1750, 160),
		};
		for (int i = 0; i < points.length; i++) {
			if (i == 0) {
				Frosty b = new Frosty(tileMap, player);
				b.setPosition(points[i].x, points[i].y);
				enemies.add(b);
				frosty = b;
				frosty.setInvincibility(true);
				// init boss hud
				bossHud = new BossHUD(frosty);
			}
			else if (i <= 8) {
				Squid b = new Squid(tileMap, player);
				b.setPosition(points[i].x, points[i].y);
				enemies.add(b);
			}
			else if (i <= 18) {
				Slugger b = new Slugger(tileMap);
				b.setPosition(points[i].x, points[i].y);
				enemies.add(b);
			}
			else {
				Bronto b = new Bronto(tileMap);
				b.setPosition(points[i].x, points[i].y);
				b.setBounds(points[i].y - 70,  points[i].y + 50);
				enemies.add(b);
			}
		}
		
		enemies.get(1).setDirection(-1);
		enemies.get(6).setDirection(-1);
		enemies.get(5).setDirection(-1);
		enemies.get(9).setDirection(-1);
		enemies.get(7).setDirection(-1);
		enemies.get(16).setDirection(-1);
		
	}
	
	private void populateWheels() {
		wheels = new ArrayList<FerrisWheels>();
		Point[] points = new Point[] {
				new Point (1450, 230), new Point(1650, 230), new Point (1855, 230)
				
		};
		for (int i = 0; i < points.length; i++) {
			wheels.add(new FerrisWheels(tileMap));	
			wheels.get(i).setInitialPos((int)points[i].getX(), (int)points[i].getY());
			wheels.get(i).init();
		}
	}
	
	private void populateCheckPoints() {
//		checkPoints[0] = new Point (450, 110);
//		checkPoints[1] = new Point (1110, 170);
//		checkPoints[2] = new Point (1920, 110);
	}

	@Override
	public void update() {
		
		// start level transition
		if (eventStart) {
			eventStart();
		}

		// check if quaking should start
		if (player.getx() >= 3970) {
			if (!tileMap.isShaking()) {
				eventQuake = true;
				tileMap.setBound((3970 + GamePanel.WIDTH / 2), 0, -(3970 - GamePanel.WIDTH/2), -80);
				tileMap.replaceTile(50, 1);
			}
		}
		// start events
		if (eventQuake) {
			bossHud.loadHP();
			eventQuake();
		}
	
		// check if levelEnd event should start
		if (player.getx() > 4130 && player.getx() < 4140) {
			eventWalk = true;
		}

		// plays levelEnd walking event
		if (eventWalk) {
			// updates fireworks
			int fireWorksCount = 0;
			for (int i = 0; i < fireworks.size(); i++) {
				if (!fireworks.get(i).playedOnce()) {
					fireworks.get(i).update();
					break;
				} else {
					fireWorksCount++;
				}
			}
			if (fireWorksCount == fireworks.size()) {
				for (int i = 0; i < fireworks.size(); i++) {
					fireworks.get(i).reset();
				}
			}
			eventWalk();
		}
		
		// checks if levelEnd transition should start
		if (eventEnd) {
			eventEnd();
		}
		
		for (int i = 0; i < wheels.size(); i++) {
			wheels.get(i).update();
		}
		
		// set background
		mountain.setPosition(tileMap.getx(), tileMap.gety());
		cloud.setPosition(tileMap.getx(), tileMap.gety());
				
		// update player
		player.update();
		tileMap.setPosition(GamePanel.WIDTH/2 - player.getx(), GamePanel.HEIGHT/2 - player.gety());	
		if (eventQuake) {
			tileMap.update();
		}
		else if (shake) {
			tileMap.update();
		}
		else {
			tileMap.fixBounds();
		}
		// attack enemies and getting attack detection
		player.checkAttack(enemies);
		
		// update all enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			e.update();
			if (e.isDead()) {
				enemies.remove(i);
				i--;
				explosions.add(new Explosion(e.getx(), e.gety(), "/Resources/Sprites/Enemies/explosion.gif", 6, 30, 30));
			}
		}
		if (!eventBoss) {
			shake = false;
		}
		
		if (eventBoss) {
			// update boss hud
			bossHud.update();
			eventBoss();
		}
		
		// update Explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}
		
		// checks if player died
		if (player.dead) {
			gsm.setState(3);
		}
		
	}

	@Override
	public void draw(Graphics2D g) {
		
		// draw background
		cloud.draw(g);
		mountain.draw(g);
		
		//draw tilemap
		tileMap.draw(g);
	
		// draw platform
		for (int i = 0; i < wheels.size(); i++) {
			wheels.get(i).draw(g);
		}
		
		// draw player
		player.draw(g);
		
		// drawing enemies
		for (int i = 0; i < enemies.size(); i++) {
			enemies.get(i).draw(g);
		}
		
		// draw layer 2 of tileMap
		tileMap.drawLayer2(g);
		
		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int)tileMap.getx(), (int)tileMap.gety());
			explosions.get(i).draw(g);
		}
		
		// draw hud
		hud.draw(g);
		
		// draw title
		title.draw(g);
		
		// draw transition boxes
		g.setColor(Color.BLACK);
		for (int i = 0; i < tb.size(); i++) {
			g.fill(tb.get(i));
		}
		
		// draw fireworks
		if (eventWalk && eventCount >= 150) {
			for (int i = 0; i < fireworks.size(); i++) {
				fireworks.get(i).setMapPosition((int)tileMap.getx(), (int)tileMap.gety());
			}
			for (int i = 0; i < fireworks.size(); i++) {
				if(!fireworks.get(i).playedOnce()) {
					fireworks.get(i).draw(g);
					break;
				}
			}
		}
		
		if (eventBoss || eventQuake) {
			bossHud.draw(g);
		}
		
	}
	

	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_LEFT) player.setLeft(true);
		if (k == KeyEvent.VK_RIGHT) player.setRight(true);
		if (k == KeyEvent.VK_UP) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setJabbing(true);
		}
		if (k == KeyEvent.VK_ESCAPE) {
			gsm.setPause(true);
		}
	}

	@Override
	public void keyRealeased(int k) {
		if (k == KeyEvent.VK_LEFT) player.setLeft(false);
		if (k == KeyEvent.VK_RIGHT) player.setRight(false);
		if (k == KeyEvent.VK_UP) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.count = 0;
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_F) {
			player.resetJabSFX = 0;
			player.setJabbing(false);
		}
		
	}
	
	///////// EVENTS
	// Level End walk event
		public void eventWalk() {
			eventCount++;
			player.stop();
			player.dontPlayJumpSound(true);
			
			// fix bounds
			if (player.getx() >= tileMap.getWidth() - GamePanel.WIDTH / 2) {
				tileMap.setBound(0,0, GamePanel.WIDTH - tileMap.getWidth(), -80);
			}
			
			// victory dance animation sequence
			if (eventCount == 1) {
				player.setPosition(4130, 230);
				player.setRight(true);
			}
			else if (eventCount < 150) {
				player.setLeft(false);
				player.setFacingRight(true);
				player.setRight(true);
			}
			else if (eventCount < 3050) {
				player.setAlwaysRight(true);
				if (eventCount == 150) {
					player.setAction(9);
					player.setVictoryDance(true);
				}
				else if (eventCount < 175) {
					player.getAnimation().setDelay(90);
					player.setSpeed(0.5);
					player.setRight(true);
				}
				else if (eventCount < 230) {
					player.setLeft(true);
				}
				else if (eventCount < 350){
					player.getAnimation().setDelay(80);
					player.setSpeed(0.5);
					player.setJumpSpeed(-15);
					player.setFallSpeed(0.40);
					player.setJumping(true);
					player.setRight(true);
					if (player.getCollision()) {
						player.getAnimation().setDelay(550);
					}
				}
				else if (eventCount < 394) {
					player.getAnimation().setDelay(80);
					player.setSpeed(2.5);
					player.setJumpSpeed(-25);
					player.setFallSpeed(0.6);
					player.setJumping(true);
					player.setLeft(true);
					if (player.getCollision()) System.out.println(eventCount);
				}
				else if (eventCount < 517) {
					player.getAnimation().setDelay(100);
					player.setSpeed(0.8);
					player.setRight(true);
				}
				else if (eventCount < 550) {
					player.getAnimation().setDelay(400);
				}
				else {
					player.setVictoryDance(false);
					eventCount = 0;
					eventWalk = false;
					eventEnd = true;
				}
			}
				
			// queues clear level music
			if (!Player.clearStageMusic && eventCount == 150) {
				Player.clearStageMusic = true;
			}
		}
	
	// Level End Teleport Event
	public void eventEnd() {
		eventCount ++;
		player.stop();
		player.setAction(7);
		if (eventCount == 1) {
			tb.clear();
			tb.add(new Rectangle(0, 0 , GamePanel.WIDTH, GamePanel.HEIGHT / 2));
			tb.add(new Rectangle(0, 0, (GamePanel.WIDTH / 2) - 40, GamePanel.HEIGHT));
			tb.add(new Rectangle(GamePanel.WIDTH, 0, GamePanel.WIDTH, GamePanel.HEIGHT));
			tb.add(new Rectangle(0, GamePanel.HEIGHT, GamePanel.WIDTH, GamePanel.HEIGHT / 2));
		}
		else if (eventCount > 1 && eventCount < 60) {
			tb.get(0).height += 1;
			tb.get(1).width += 3;
			tb.get(2).x -= 3;
			tb.get(3).y -= 1;
		}
		else if (eventCount == 60) {
			eventEnd = false;
			eventCount = 0;
			tb.clear();
			gsm.setState(2);
		} 
	}
	
	// Level Start Event
	public void eventStart() {
		eventCount++;
		
		if (eventCount == 1) {
			tb.clear();
			tb.add(new Rectangle(0, 0 , GamePanel.WIDTH, GamePanel.HEIGHT / 2));
			tb.add(new Rectangle(0, 0, GamePanel.WIDTH / 2, GamePanel.HEIGHT));
			tb.add(new Rectangle(GamePanel.WIDTH / 2 , 0, GamePanel.WIDTH / 2, GamePanel.HEIGHT));
			tb.add(new Rectangle(0, GamePanel.HEIGHT / 2, GamePanel.WIDTH, GamePanel.HEIGHT / 2));
		}
		else if (eventCount > 1 && eventCount < 60) {
			tb.get(0).height -= 4;
			tb.get(1).width -= 6;
			tb.get(2).x += 6;
			tb.get(3).y += 4;
		}
		else if (eventCount == 60) {
			eventStart = false;
			eventCount = 0;
			tb.clear();
		}
	}
	
	// earthquake start
	public void eventQuake () {
		eventCount++;
		player.stop();
		
		if (eventCount == 1 ) {
			player.setAction(0);
			player.setPosition(3970, 230);
		}
		if (eventCount == 60) player.setEmote(Player.CONFUSED);
		if (eventCount == 120) {
			player.setEmote(Player.NONE);
			frosty.setAction(5);
		}
		if (eventCount == 150) {
			tileMap.setShaking(true, 10);
		}
		if (eventCount == 180) player.setEmote(Player.SURPRISED);
		if (eventCount == 300) {
			player.setEmote(Player.NONE);
			eventQuake = false;
			eventBoss = true;
			eventCount = 0;
		}
	}
	
	// boss fight start
	public void eventBoss() {
		
		// fix audio plz
		
		eventCount ++;
		if (frosty.isDead()) {
			eventCount = 0;
			eventBoss = false;
			shake = false;
			tileMap.setBound(tileMap.getWidth(), 0, 0, -80);
			tileMap.replaceTile(1, 50);
			return;
		}
		else if (player.dead) {
			eventCount = 0;
			eventBoss = false;
			shake = false;
			return;
		}
		// charging
		if (eventCount < 1500) {
			if (eventCount == 1) frosty.setAction(1);
			if (frosty.getXCollision()) shake = true;
			else shake = false;
			if (frosty.getInvincibility()) frosty.setAction(1);
			else {
				// activate vulnerability for boss when it hits wall
				frosty.setAction(6);
			}
		}
		// quake
		else if (eventCount < 1600) {
			shake = true;
			if (eventCount == 1500) frosty.setAction(5);
			if (player.getx() > frosty.getx()) {
				frosty.setDirection(1);
				frosty.setVector(0, 0);
			}
			else {
				frosty.setDirection(-1);
				frosty.setVector(0, 0);
			}
		}
		// jumping
		else if (eventCount < 3000) {
			shake = false;
			// ensures that frosty lands before making next action
			if (eventCount == 1600) frosty.setAction(3);
			if (frosty.getYCollision()) shake = true;
			else shake = false;
			
		}
		// quake
		else if (eventCount < 3100) {
			if (!frosty.getFalling()) {
				shake = true;
				frosty.resetDPSWindowCount();
				if (eventCount == 3000)
					frosty.setAction(5);
				if (player.getx() > frosty.getx()) {
					frosty.setDirection(1);
					frosty.setVector(0, 0);
				} else {
					frosty.setDirection(-1);
					frosty.setVector(0, 0);
				}
			}
			else eventCount--;
		}
		// throwing
		else if (eventCount < 4600) {
			shake = false;
			if (frosty.getXCollision()) shake = true;
			if (!frosty.getFalling()) {
				if (eventCount == 3100) {
					frosty.setAction(2);
					frosty.add();
				}
				if (frosty.getIceBreakCount() >= 3) {
					if (!frosty.getInvincibility()) {
						frosty.setAction(6);
					}
					else frosty.setAction(1);
				}
				else if (eventCount % 90 == 0) {
					if (player.getx() > frosty.getx()) {
						frosty.setDirection(1);
					}
					else {
						frosty.setDirection(-1);
					}
					frosty.setAction(2);
					frosty.add();
				}
			}
		}
		else {
			eventCount = 0;
		}

		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
