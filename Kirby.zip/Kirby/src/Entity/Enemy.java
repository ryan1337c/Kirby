package Entity;

import TileMap.*;
public class Enemy extends MapObject{
	
	// enemy stuff
	protected int health;
	protected int maxHealth;
	protected boolean dead;
	protected int damage;
	protected boolean invincibility;
	
	protected boolean flinching;
	protected long flinchTimer;
	
	
	public Enemy (tileMap tm) {
		super(tm);
		checkIsPlayer(false);
	}
	
	public boolean isDead() { return dead; }
	
	public int getDamage () { return damage; }
	
	public void hit (int damage) {
		if (dead || flinching) return;
		health -= damage;
		if (health < 0) health = 0;
		if (health == 0) dead = true;
		flinching = true;
		flinchTimer = System.nanoTime();
		
	}
	
	public void update() {}
	
	public boolean setFlinch(boolean b) {
		return b;
	}
	
	public void setDirection(int num) {
		if (num == -1) {
			left = true;
			facingRight = false;
			right = false;
		}
	}
	
	public void setBoss (boolean b) {
		isBoss = b;
	}
	public void setInvincibility (boolean b) {
		invincibility = b;
	}
	public void setProjectileIdentity(boolean b) { projectile = b;}
	
	public boolean getBoss( ) {
		return isBoss;
	}
	
	public boolean getInvincibility() {return invincibility;}
	public boolean getProjectileIdentity() { return projectile;}
	public boolean getXCollision() { return xcollision;}
	public boolean getYCollision() { return ycollision;}
		
}
