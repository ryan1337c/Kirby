package Entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import Game.GamePanel;

public class BossHUD {
	
	private Enemy boss;
	private BufferedImage fullHPBar, currentHPBar, bossIcon, boarder;
	private float hpPercentage;
	private float barWidth;
	private int maxWidth, heightBar;
	private int hpCount;
	
	public BossHUD(Enemy mob) {
		boss = mob;
		maxWidth = 120;
		heightBar = 60;
		try {
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/HUD/bossHPbar.png"));
			for (int i = 0; i < 3; i++) {
				if (i == 0) fullHPBar = spritesheet.getSubimage(0, i * heightBar, maxWidth, heightBar);
				else if (i==1) bossIcon = spritesheet.getSubimage(0, i * heightBar, 60, heightBar);
				else boarder = spritesheet.getSubimage(0, i * heightBar, maxWidth + 60, heightBar);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void update() {
		hpPercentage = (float) boss.health / boss.maxHealth;
		if (hpPercentage <= 0) return;
		if ((int) (maxWidth * hpPercentage) == 0) return;
		currentHPBar = fullHPBar.getSubimage(0, 0, (int) (maxWidth * hpPercentage), heightBar);
	}
	
	public void loadHP() {
		hpCount += 5;
		hpPercentage = (float) hpCount / boss.maxHealth;
		if (hpCount > boss.maxHealth) return;
		if ((int) (maxWidth * hpPercentage) == 0) return;
		currentHPBar = fullHPBar.getSubimage(0, 0, (int) (maxWidth * hpPercentage), heightBar);
	}
	
	public void draw(Graphics2D g) {
		g.drawImage(boarder, GamePanel.WIDTH - maxWidth - 4, GamePanel.HEIGHT - (heightBar - 5), null);
		g.drawImage(currentHPBar, GamePanel.WIDTH - maxWidth - 4, GamePanel.HEIGHT - (heightBar - 5), null);
		g.drawImage(bossIcon, GamePanel.WIDTH - maxWidth - 21, GamePanel.HEIGHT - (heightBar - 12), null);
		
	}
	
}
