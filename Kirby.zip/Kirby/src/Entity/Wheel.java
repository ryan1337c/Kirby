package Entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import GameState.GameState;
import TileMap.tileMap;

public class Wheel extends MapObject{
	
	private double oTheta;
	private BufferedImage image;
	//private double dx, dy;
	private int xPos, yPos;
	public Wheel(tileMap tm) {
		super(tm);
		
		// setting sprite
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/Resources/Tilesets/platForm.png"));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void init(int x, int y, double startPoint) {
		xPos = x;
		yPos = y;
		oTheta = startPoint;
		
		cwidth = 30;
		cheight = 15;
	
	}
	public int getYPos() {
		return yPos;
	}
	public void update () {
			oTheta += 0.01;
			if (oTheta > (Math.PI * 2)) {
				oTheta = 0;
			}
			dx = 50 * Math.cos(oTheta) + xPos;
		    dy = 50 * Math.sin(oTheta) + yPos;
		    setPosition(dx, dy);
	    
	}
	
	public double getAngle() {
		return oTheta;
	}
	
	public double getXSpeed() {
		return Math.cos(oTheta);
	}
	
	public void draw(Graphics2D g) {
		setMapPosition();
		
		g.drawImage(image, (int) (x + xmap - cwidth/2), (int) (y + ymap - cheight/2), cwidth, cheight, null);
	}
	
	
}
