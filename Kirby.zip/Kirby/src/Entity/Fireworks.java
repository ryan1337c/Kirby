package Entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import TileMap.tileMap;

public class Fireworks{
	
	private int x;
	private int y;
	
	private int xmap;
	private int ymap;
	
	private int width;
	private int height;
	
	private Animation animation;
	private BufferedImage[] sprites;
	
	private boolean remove;
	
	public Fireworks(int x, int y, String path) {
		this.x = x;
		this.y = y;
		
		width = 60;
		height = 60;
		
		try {
			sprites = new BufferedImage[4];
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream(path));
			for (int i = 0; i < sprites.length; i++) {
				BufferedImage bi = spritesheet.getSubimage(i * width, 0, width, height);
				sprites[i] = bi;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		animation = new Animation();
		animation.setFrames(sprites);
		animation.setDelay(100);
	}
	
	public boolean playedOnce() { return animation.hasPlayedOnce(); }
	
	public void update() {
		animation.update();
	}
	
	public void reset() {
		animation.setFrames(sprites);
	}
	
	public void setMapPosition(int x, int y) {
		xmap = x;
		ymap = y;
	}
	
	public void draw(Graphics2D g) {
		g.drawImage(animation.getImage(), x + xmap - width / 2, y + ymap - height / 2, null);
	}
}
