package Entity;


import TileMap.Tile;



import TileMap.tileMap;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.lang.reflect.Array;
import java.util.ArrayList;

import Game.GamePanel;

public abstract class MapObject {
	
	// tile stuff
	protected tileMap tileMap;
	protected int tileSize;
	protected double xmap;
	protected double ymap;
	
	// position and vector
	protected double x;
	protected double y;
	protected double dx;
	protected double dy;
	
	// dimensions
	protected int width;
	protected int height;
	
	// collision box
	protected int cwidth;
	protected int cheight;
	
	// collision
	protected int currRow; // currRow and currCol are in tileSize not in pixels
	protected int currCol;
	protected double xdest;
	protected double ydest;
	protected double xtemp;
	protected double ytemp;
	protected int topLeft;
	protected int topRight;
	protected int bottomLeft;
	protected int bottomRight;
	protected boolean isPlatform;
	protected boolean collision;
	protected boolean xcollision;
	protected boolean ycollision;
	
	// animation
	protected Animation animation;
	protected int currentAction;
	protected int previousAction;
	protected boolean facingRight;
	
	// movement
	protected boolean alwaysFacingR;
	protected boolean left;
	protected boolean right;
	protected boolean up;
	protected boolean down;
	protected boolean jumping;
	protected boolean falling;
	protected boolean swimming;
	protected boolean wasSwimming;
	public static boolean finishDiving;
	
	// movement attributes
	protected double moveSpeed;
	protected double maxSpeed;
	protected double stopSpeed;
	protected double fallSpeed;
	protected double maxFallSpeed;
	protected double jumpStart;
	protected double stopJumpSpeed;
	protected double knockbackSpeed;
	protected double swimSpeed;
	protected double sinkSpeed;
	private final double jumpOutOfWater = -3.1;
	
	// level bounds
	public static int levelBound;
	
	// audio for splashing
	private boolean hasPlayedOnce;
	
	// Audio stuff
	protected boolean dontPlayJump;
	
	// checks ferriswheel
	protected boolean hasLandedOnce;
	
	// check button stuff
	public static boolean buttonPressed;
	public static boolean fillBlocks;
	private int buttonPos;
	
	// player bumping into objects SFX
	private boolean hasPlayedOnceBump;
	private boolean isPlayer;
	
	// identity
	protected boolean isBoss;
	protected boolean projectile;
	
	// constructor
	public MapObject (tileMap tm) {
		tileMap = tm;
		tileSize = tm.getTileSize();
	}
	
	// creates collision box around objects
	public boolean intersects (MapObject o) {
		Rectangle r1 = getRectangle();
		Rectangle r2 = o.getRectangle();
		return (r1.intersects(r2));
	}
	
	public Rectangle getRectangle() {
			// x and y starts in the middle
			return new Rectangle ((int)x - cwidth/2, (int)y - cheight / 2, cwidth, cheight);
	}
	
	public void calculateCorners (double x, double y){
		
		int leftTile = (int) (x - cwidth / 2) / tileSize;
		int rightTile = (int) (x + cwidth / 2 - 1) / tileSize;
		int topTile = (int) (y - cheight / 2) / tileSize;
		int bottomTile = (int) (y + cheight / 2 - 1) / tileSize;
		
		topLeft = tileMap.getType(topTile, leftTile);
		topRight = tileMap.getType(topTile, rightTile);
		bottomLeft = tileMap.getType(bottomTile, leftTile);
		bottomRight = tileMap.getType(bottomTile, rightTile);
		
		// gets button position from the bottom
		buttonPos = tileMap.getTile(topTile, leftTile);
	}
	
	public void checkTileMapCollision() {
		currCol = (int)x / tileSize;
		currRow = (int)y / tileSize;
		
		xdest = x + dx;
		ydest = y + dy;
		
		xtemp = x;
		ytemp = y;
		
		collision = false;
		
		// checks y direction collision
		calculateCorners(x, ydest);
		// checks top two corners of collided tile
		if (dy < 0) {
			if (topLeft == Tile.BLOCKED || topRight == Tile.BLOCKED) { 
				collision = true;
				// setting object position directly below BLOCKED/SOLID Object after collision
				dy = 0;
				ytemp = currRow * tileSize + cheight / 2;
				// checks if player touched button from the bottom
				if (buttonPos == 47) {
					buttonPressed = true;
					
				}
			}
			else if (bottomLeft == Tile.WATER || bottomRight == Tile.WATER) {
				ytemp += dy;
				swimming = true;
			}
			else {
				if (swimming && isPlayer) {
					swimming = false;
					dy = jumpOutOfWater;
					// resets splashing audio
					hasPlayedOnce = false;
					finishDiving = false;
				}
				if (!(ytemp + dy < 0)) ytemp += dy;
			}
		}
		// checks bottom corners of collided tile
		if (dy > 0) {
			if (bottomLeft == Tile.BLOCKED || bottomRight == Tile.BLOCKED) {
				collision = true;
				dy = 0;
				falling = false;
				ytemp = (currRow + 1) * tileSize - cheight / 2;
			}
			else if ((ytemp + dy + cheight) >= levelBound){
				collision = true;
				dy = 0;
			}
			else if (bottomLeft == Tile.WATER || bottomRight == Tile.WATER) {
				// player will sink at constant speed
				ytemp += dy;
				swimming = true;
				// plays splashing audio
				hasPlayedOnce = true;
				
			}
			else {
				ytemp += dy;
				swimming = false;
			}
			if (isBoss && ytemp > 210) {
				collision = true;
				ytemp = 210;
				falling = false;
				jumping = false;
				dy = 0;
			}
		}
		calculateCorners(xdest, y);
		// checks top and bottom left corners of collided tile
		if (dx < 0) {
			if (topLeft == Tile.BLOCKED || bottomLeft == Tile.BLOCKED) {
				collision = true;
				dx = 0;
				xtemp = currCol * tileSize + cwidth / 2;
			}
			// keeps player from exiting out of the map to the left at the start of level
			else if (xtemp + dx <= 0) {
				dx = 0;
			}
			else if (topLeft == Tile.WATER || bottomLeft == Tile.WATER) {
				// player will swim at a constant speed
				xtemp += dx;
				swimming = true;	
			}
			else {
				xtemp += dx;
				swimming = false;
			}
		}
		// checks top and bottom right corners of collided tile
		if (dx > 0) {
			if (topRight == Tile.BLOCKED || bottomRight == Tile.BLOCKED) {
				collision = true;
				dx = 0;
				xtemp =(currCol + 1) * tileSize - cwidth / 2 + 0.7;
			}
			else if (topRight == Tile.WATER || bottomRight == Tile.WATER) {
				// player will swim at a constant speed
				xtemp += dx;
				swimming = true;
			}
			else {
				xtemp += dx;
				swimming = false;
			}
		}
		
		// bumping noise when player walks into wall
		if (isPlayer && (topLeft == Tile.BLOCKED || topRight == Tile.BLOCKED || bottomLeft == Tile.BLOCKED || bottomRight == Tile.BLOCKED)) {
			if (!hasPlayedOnceBump) {
				hasPlayedOnceBump = true;
			}
		}
		else {
			hasPlayedOnceBump = false;
		}
		
		// resets swimming when player leaves water via moving platform
		if (!(bottomLeft == Tile.WATER || bottomRight == Tile.WATER) && isPlayer) {
			swimming = false;
			// resets splashing audio
			hasPlayedOnce = false;
			finishDiving = false;
		}
		
		// checks if player / mob ran off a cliff
		if (!falling) {

			if (left && !isPlayer)
				calculateCorners(x - cwidth, ydest + 1);
			else if (right && !isPlayer)
				calculateCorners(x + cwidth, ydest + 1);
			else
				calculateCorners(x, ydest + 1);
			
			if (!isBoss) {
				if (bottomLeft == Tile.WATER && bottomRight == Tile.WATER) {
					swimming = true;
					falling = true;
				} 
				 else if (!(bottomLeft == Tile.BLOCKED) && !(bottomRight == Tile.BLOCKED) && !hasLandedOnce) {
					falling = true;
					Player.count = 0;
					// keeps enemies from falling off cliffs so that they can turn back
					if (!isPlayer && !projectile) {
						dx = 0;
					}
				}
			}
		}
		
	}
	
	public boolean checkIfOffMap() {
		if (ytemp + dy + cheight >= levelBound) {
			dy = 0;
			dx = 0;
			return true;
		}
		return false;
	}
	
	public int getx() { return (int)x; }
	public int gety() { return (int)y; }
	public int getWidth() { return width; }
	public int getHeight() { return height; }
	public int getCWidth() { return cwidth; }
	public int getCHeight() { return cheight; }
	public boolean getCollision() { return collision;}
	public boolean getFalling() { return falling;}
	
	// global static position 
	public void setPosition(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public void setVector(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	public void setAlwaysRight(boolean b) {
		alwaysFacingR = b;
	}
	
	public void dontPlayJumpSound(boolean b) {
		dontPlayJump = b;
	}
	
	public void checkIsPlayer(boolean b) { isPlayer = b;}
	
	// Map position
	public void setMapPosition() {
		// note xmap and ymap are essentially the coordinates for the top left of the screen (0,0) 
		xmap = tileMap.getx();
		ymap = tileMap.gety();
	}
	
	public void setLeft (boolean b) { left = b; } 
	public void setRight (boolean b) { right = b; }
	public void setUp (boolean b) { up = b; }
	public void setDown (boolean b) { down = b; }
	public void setJumping (boolean b) { jumping = b; }
	
	public boolean notOnScreen () {
		return x + xmap + width < 0 || x + xmap - width > GamePanel.WIDTH
				|| y + ymap + height < 0 || y + ymap - height > GamePanel.HEIGHT;		
	}
	
	public void draw (Graphics2D g) {
	
		if (facingRight || alwaysFacingR) {
			g.drawImage(animation.getImage(), (int) (x + xmap - width/2), (int) (y + ymap - height/2), null);
		}
		else {
			g.drawImage (animation.getImage(), (int) (x + xmap - width/2 + width), (int) (y + ymap - height/2), -width, height, null);
			
		}
	}
	
	
	

}
