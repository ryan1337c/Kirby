package Entity;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Game.GamePanel;

public class Title {
	
	// titles
	private ImageIcon titleIcon;
	private Image title;
	private BufferedImage subTitle;
	private int titleCount;
	private float tick = (float) 0.1;
	private boolean tickDown;
	
	public Title(String header, String subHeader) {
		// setting titles
		try {
			titleIcon = new ImageIcon(getClass().getResource(header));
			title = titleIcon.getImage();
			subTitle = ImageIO.read(getClass().getResourceAsStream(subHeader));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void draw (Graphics2D g) {
		
		// draw title
		if (titleCount <= 450) {
			if (tick >= 1) {
				tick = 1;
				// titles delay
				if (titleCount > 300)
					tickDown = true;
			}
			if (tick < 0)
				tick = 0;
			// translucent effects on titles
			AlphaComposite alcom = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tick);
			g.setComposite(alcom);
			g.drawImage(title, GamePanel.WIDTH / 2 - 70, 0, null);
			g.drawImage(subTitle, GamePanel.WIDTH / 2 - 70, 50, null);
			// fade in
			if (!tickDown) {
				tick += 0.008;
			}
			// fade out
			else {
				tick -= 0.008;
			}
			titleCount++;
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
		}
	}
	
	
}
