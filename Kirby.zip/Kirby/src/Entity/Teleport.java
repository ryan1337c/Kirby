package Entity;

public class Teleport {
	
	private Player player;
	
	public Teleport (Player player) {
		this.player = player;
		
	}

}
