package Entity.enemies;

import java.awt.Graphics2D;

import Entity.Animation;
import Entity.Enemy;
import Entity.MapObject;
import Entity.Player;
import GameState.Level2State;
import TileMap.tileMap;

public class Ice extends Enemy{
	
	private double launchSpeed;
	private Animation animation;
	private tileMap tm;
	private Player player;
	private Frosty f;
	public Ice (tileMap tm, Player player, Frosty f) {
		super(tm);
		
		this.tm = tm;
		this.player = player;
		this.f = f;
		
		// ice stuff
		moveSpeed = 2.0;
		damage = 2;
		launchSpeed = -5.0;
		fallSpeed = 2.0;
		
		dy = launchSpeed;
		
		width = cwidth = height = cheight = 40;
		
		right = f.getRight();
		left = !f.getRight();
		facingRight = f.getFacingRight();
		
		x = f.getx();
		y = f.gety() - f.getCHeight() / 2 - 50;
		
		// set animation
		animation = new Animation();
		animation.setFrames(Level2State.projectiles.get("ice"));
		animation.setDelay(-1);
		
		setBoss(false);
		setProjectileIdentity(true);
	}
	
	public void update() {
		
		// horizontal movement
		if (right) dx  = moveSpeed;
		else if (left) dx = -moveSpeed;
		
		// vertical movement
		if (y < f.gety() - f.getCHeight() / (2 - 50) - 10) {
			dy = fallSpeed;
		}
		
		checkTileMapCollision();

		if (player.intersects(this)) {
			// check collision
			player.hit(damage);
			dead = true;
		}
		if (dx == 0) {
			dead = true;
		}
		setPosition(xtemp, ytemp);
			
	}
	
	public void draw(Graphics2D g) {
		setMapPosition();
		g.drawImage(animation.getImage(), (int) (x + xmap - cwidth / 2), (int)(y + ymap - cheight / 2), null);
	}

}
