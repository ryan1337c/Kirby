package Entity.enemies;

import TileMap.tileMap;


import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import Entity.Animation;
import Entity.BossHUD;
import Entity.Enemy;
import Entity.Explosion;
import Entity.Player;

public class Frosty extends Enemy{
	
	private ArrayList <BufferedImage[]> sprites;
	private int []numFrames = {
			2, 4, 4, 3, 1, 4, 1, 1
	};
	
	private int currentAction;
	
	private final int IDLE = 0;
	private final int CHARGING = 1;
	private final int THROW = 2;
	private final int JUMP = 3;
	private final int FLINCH = 4;
	private final int ANGRY = 5;
	private final int VULNERABLE = 6;
	private final int FALL = 7;
	
	private boolean start;
	
	// attack rotation
	private int type;
	private int dpsWindow;
	private int slidingTimer;
	
	// ice cube
	private ArrayList <Ice> ice= new ArrayList<Ice>();
	private ArrayList <Explosion> explosions = new ArrayList<Explosion>();
	
	private tileMap tm;
	protected Player player;
	private int iceBreakCount;
	
	public Frosty (tileMap tm, Player player) {
		super(tm);
		this.player = player;
		this.tm = tm;
		
		// enemy stuff
		moveSpeed = 1.5;
		fallSpeed = 0.2;
		stopSpeed = 0.05;
		maxFallSpeed = 10.0;
		jumpStart = -6.0;
		knockbackSpeed = 0.3;

		// tile sheet size
		width = 90;
		height = 90;

		// enemy size
		cwidth = 75;
		cheight = 50;

		health = maxHealth = 1000;
		damage = 1;
		
		
		try {
			sprites = new ArrayList<BufferedImage[]>();
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Enemies/level2Boss.png"));
			for (int i = 0; i < numFrames.length; i++) {
				BufferedImage []bi = new BufferedImage[numFrames[i]];
				for (int j = 0; j < numFrames[i]; j++) {
					bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);
				}
				sprites.add(bi);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		currentAction = IDLE;
		animation = new Animation();
		animation.setFrames(sprites.get(IDLE));
		animation.setDelay(900);
		
		// set identity to boss
		setBoss(true);
		
		facingRight = false;
		left = true;
		
	}
	
	public void setAction(int num) { 
		type = num;
		if (type == JUMP) {
			jumping = true;
		}
	}
	public void setDirection(int num) {
		if (num == 1) {
			facingRight = true;
			right = true;
			left = false;
		}
		else {
			facingRight = false;
			left = true;
			right = false;
		}
	}
	
	public int getAction() { return type;}
	public int getx() { return (int) x;}
	public int gety() { return (int) y;}
	public boolean getRight() { return right;}
	public boolean getFacingRight() { return facingRight;}
	public int getCHeight() { return cheight;}
	public int getCWidth() { return cwidth;}
	public int getIceBreakCount() { return iceBreakCount;}
	
	public void resetIceBreakCount() {
		iceBreakCount = 0;
	}
	
	public void add() {
		ice.add(new Ice(tileMap, player, this));
	}
	
	public void resetDPSWindowCount() { 
		dpsWindow = 0;
	}
	
	public void getNextPosition() {
		// movement
		if (type == VULNERABLE) {
			dpsWindow++;
			if (dpsWindow > 20) xcollision = false;
			if (dpsWindow < 50) {
				if (left) dx = -knockbackSpeed;
				if (right) dx = knockbackSpeed;
			}
			else if (dpsWindow < 200) {
				dx = 0;
			}
			else {
				setInvincibility(true);
				dpsWindow = 0;
				resetIceBreakCount();
				if (right) facingRight = true;
				if (left) facingRight = false;
			}
		}
		if (left && (type == 1 || type == 3 || type == 7)) {
			dx = -moveSpeed;
		} else if (right && (type == 1 || type == 3 || type == 7)) {
			dx = moveSpeed;
		}
		else {
			if (dx > 0) {
				dx -= stopSpeed;
				if (dx < 0) {
					dx = 0;
				}
			} else if (dx < 0) {
				dx += stopSpeed;
				if (dx > 0) {
					dx = 0;
				}
			}
		}
		if (jumping && !falling) {
			dy += jumpStart;
			falling = true;
			setInvincibility(true);
		}
		if (!falling && (type == JUMP || type == FALL)) {
			slidingTimer++;
			if (slidingTimer < 20) ycollision = true;
			else ycollision = false;
			// boss will slide for a brief period after jumping
			if (slidingTimer < 50) {
				type = FALL;
			}
			else {
				jumping = true;
				slidingTimer = 0;
				type = JUMP;
			}
		}
		if (falling) {
			dy += fallSpeed;
			if (dy > maxFallSpeed) dy = maxFallSpeed;
		}
		
	}
	
	public void update() {
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);
		
		// updates ice attack
		for (int i = 0; i < ice.size(); i++) {
			if (ice.get(i).isDead()) {
				iceBreakCount++;
				explosions.add(new Explosion(ice.get(i).getx(), ice.get(i).gety(), "/Resources/Sprites/Enemies/iceExplosion.png", 5, 40, 40));
				ice.remove(i);
				i--;
			}
			else ice.get(i).update();
		}
		
		// updates explosion
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}
		
		// check flinching
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 200) {
				flinching = false;
			}
		}
		
		// if it hits a wall
		if (right && dx == 0 && (type == CHARGING || type == JUMP || type == FALL)) {
			left = true;
			right = false;
			if (type == CHARGING) {
				setInvincibility(false);
				xcollision = true;
			}
			else {
				if (right) facingRight = true;
				if (left) facingRight = false;
			}
		} else if (left && dx == 0 && (type == CHARGING|| type == JUMP || type == FALL)) {
			right = true;
			left = false;
			if (type == CHARGING) {
				setInvincibility(false);
				xcollision = true;
			}
			else {
				if (right) facingRight = true;
				if (left) facingRight = false;
			}
		}
		
		if (type == CHARGING) {
			if (currentAction != CHARGING) {
				currentAction = CHARGING;
				animation.setFrames(sprites.get(CHARGING));
				animation.setDelay(100);
				width = 90;
			}
		}
		else if (type == THROW) {
			if (currentAction != THROW) {
				currentAction = THROW;
				animation.setFrames(sprites.get(THROW));
				animation.setDelay(150);
				width = 90;
			}
		}
		else if (dy < 0) {
			if (currentAction != JUMP) {
				currentAction = JUMP;
				animation.setFrames(sprites.get(JUMP));
				animation.setDelay(-1);
				width = 90;
			}
		}
		else if (dy > 0 || (dy == 0 && (type == FALL || type == JUMP))) {
			if (currentAction != FALL) {
				currentAction = FALL;
				animation.setFrames(sprites.get(FALL));
				animation.setDelay(-1);
				width = 90;
			}
		}
		else if (type == ANGRY) {
			if (currentAction != ANGRY) {
				currentAction = ANGRY;
				animation.setFrames(sprites.get(ANGRY));
				animation.setDelay(100);
				width = 90;
			}
		}
		else if (type == VULNERABLE) {
			if (currentAction != VULNERABLE) {
				currentAction = VULNERABLE;
				animation.setFrames(sprites.get(VULNERABLE));
				animation.setDelay(100);
				width = 90;
			}
		}
		else {
			if (currentAction != IDLE) {
				currentAction = IDLE;
				animation.setFrames(sprites.get(IDLE));
				animation.setDelay(400);
				width = 90;
			}
		}
		
		if (type == THROW && animation.hasPlayedOnce()) {
			type = IDLE;
		}
		// updates animation
		animation.update();
		
		
		
	}
	
	public void draw (Graphics2D g) {
		setMapPosition();
		// draw flinching
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed / 100 % 2 == 0) {
				currentAction = FLINCH;
				width = 90;
				animation.setFrames(sprites.get(FLINCH));
				animation.setDelay(-1);
			}
		}
		// draw ice
		for (int i = 0; i < ice.size(); i++) {
			ice.get(i).draw(g);
		}

		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int) tm.getx(), (int) tm.gety());
			explosions.get(i).draw(g);
		}
		
		super.draw(g);
	}

}
