package Entity.enemies;

import Entity.Enemy;
import Entity.Explosion;
import Entity.Player;
import TileMap.*;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import Entity.Animation;
import javax.imageio.ImageIO;

public class Squid extends Enemy {
	
	private BufferedImage [] sprites;
	private int currentAction;
	private static int MOVING = 1;
	private static int ATTACK = 2;
	

	private tileMap tm;
	private Player player;
	
	// bomb stuff
	private ArrayList <Bomb> bombs = new ArrayList<Bomb>();
	private ArrayList <Explosion> explosions = new ArrayList<Explosion>();
	
	// delay attack
	private int countStop;
	
	public Squid(tileMap tm, Player player) {
		super(tm);
		
		this.tm = tm;
		this.player = player;
		
		// enemy stuff
		width = 30;
		height = 40;
		
		cwidth = 30;
		cheight = 40;
		
		moveSpeed = 0.3;
		maxSpeed = 0.3;
		
		health = maxHealth = 20;
		damage = 1;
		
		// init sprite
		try {
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Enemies/squid.png"));
			sprites = new BufferedImage[4];
			for (int i = 0; i < sprites.length; i++) {
				sprites[i] = spritesheet.getSubimage(i * width, 0, width, height);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		animation = new Animation();
		animation.setFrames(sprites);
		animation.setDelay(300);
		currentAction = MOVING;
		right = true;
		facingRight = true;
	}
	
	public void getNextPosition() {
		
		// attack pause
		countStop++;
		if (countStop >= 130 && countStop <= 200) {
			dx = 0;
			currentAction = ATTACK;
			// adds bomb
			if (countStop == 130) {
				Bomb bombOut = new Bomb(tm, player);
				bombOut.setPosition(x, y);
				bombs.add(bombOut);
			}
			if (countStop == 200) countStop = 0;
		}

		// movement
		else if (left) {
			dx -= moveSpeed;
			if (dx < -maxSpeed) {
				dx = -maxSpeed;
			}
			currentAction = MOVING;
		} 
		else if (right) {
			dx += moveSpeed;
			if (dx > maxSpeed) {
				dx = maxSpeed;
			}
			currentAction = MOVING;
		}
	}
	
	public void update() {
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);
		
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 200) {
				flinching = false;
			}
		}
		
		// if it hits a wall
		if (right && dx == 0) {
			if (currentAction == MOVING) {
				right = false;
				left = true;
				facingRight = false;
			}
		} else if (left && dx == 0) {
			if (currentAction == MOVING) {
				left = false;
				right = true;
				facingRight = true;
			}
		}
		
		// updates bombs
		for (int i = 0; i < bombs.size(); i++) {
			if (bombs.get(i).isDead()) {
				explosions.add(new Explosion(bombs.get(i).getx(), bombs.get(i).gety(), "/Resources/Sprites/Enemies/bombExplosion.png", 6, 30, 30));
				bombs.remove(i);
				i--;
			}
			else bombs.get(i).update();
		}
		
		// updates explosion
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}
		
		animation.update();
	}
	
	public void draw(Graphics2D g) {
		setMapPosition();
		
		// draw bombs
		for (int i = 0; i < bombs.size(); i++) {
			bombs.get(i).draw(g);
		}
		
		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int) tm.getx(), (int) tm.gety());
			explosions.get(i).draw(g);
		}
		
		// check flinching
		if (flinching) {
			return;
		}
			
		super.draw(g);
	}
	

}
