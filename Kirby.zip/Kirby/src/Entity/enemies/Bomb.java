package Entity.enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import Entity.Animation;
import Entity.Enemy;
import Entity.Explosion;
import Entity.Player;
import TileMap.*;
public class Bomb extends Enemy{
	
	private BufferedImage bomb;
	private tileMap tm;
	private Player player;
	
	public Bomb(tileMap tm, Player player) {
		super(tm);
		
		this.tm = tm;
		this.player = player;
		
		// init
		moveSpeed = 0.5;
		
		width = 30;
		height = 30;
		
		cwidth = 20;
		cheight = 20;
		
		damage = 2;
	
		
		try {
			// init squid Bomb
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Enemies/bomb.png"));
			bomb = spritesheet.getSubimage(0, 0, 30, 30);	
			
		}
		catch(Exception e) {}
		down = true;
		setProjectileIdentity(true);
	}
	
	public void getNextPosition() {
		if (down) {
			dy = moveSpeed;
		}
	}
	
	public void update() {
		getNextPosition();
		checkTileMapCollision();
		if (player.intersects(this)) {
			// check collision
			player.hit(damage);
			dead = true;
		}
		if (getCollision()) {
			dead = true;
		}
		setPosition(xtemp, ytemp);
	}
	
	public void draw(Graphics2D g) {
		setMapPosition();
		g.drawImage(bomb, (int) (x + xmap - cwidth / 2), (int)(y + ymap - cheight / 2), null);
	}
	
	

}
