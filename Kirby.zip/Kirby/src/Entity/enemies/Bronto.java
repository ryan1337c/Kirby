package Entity.enemies;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;

import Entity.Animation;
import Entity.Enemy;
import TileMap.*;

public class Bronto extends Enemy {
	
	private ArrayList <BufferedImage[]> sprites = new ArrayList <BufferedImage[]>();
	private int[] numFrames = {
			2, 2
	};
	private int currentAction;
	private final int FLYING = 0;
	private final int FLINCH = 1;
	private int maxBoundsY, minBoundsY;
	
	public Bronto (tileMap tm) {
		
		super(tm);
		
		// enemy stuff
		moveSpeed = 1;
		maxSpeed = 1;
		
		
		// tile sheet size
		width = 30;
		height = 30;
		
		// enemy size
		cwidth = 20;
		cheight = 20;
		
		health = maxHealth = 10;
		damage = 1;
		
		// load sprites
		try {
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Enemies/Bronto.png"));
			for (int i = 0; i < numFrames.length; i++) {
				BufferedImage [] bi = new BufferedImage [numFrames[i]];
				for (int j = 0; j < numFrames[i]; j++) {
					bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);
				}
				sprites.add(bi);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		animation = new Animation();
		animation.setFrames(sprites.get(FLYING));
		animation.setDelay(100);
		currentAction = FLYING;
	
		right = true;
		facingRight = true;
		up = true;
	}
	
	public void getNextPosition () {
		if (up) {
			dy -= moveSpeed;
			if (dy <= -maxSpeed) {
				dy = -maxSpeed;
			}
		} 
		if (down) {
			dy += moveSpeed;
			if (dy >= maxSpeed) {
				dy = maxSpeed;
			}
		}
	}
	
	public void setBounds(int yM, int ym) {
		maxBoundsY = yM;
		minBoundsY = ym;
	}
	
	public void setDirection(int num) {
		if (num == 1) {
			up = true;
			down = false;
		}
		else { 
			down = true;
			up = false;
		}
	}
	
	public void update() {
		
		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);
		
		// checks if boundaries are hit
		if (up && dy == 0)  {
			up = false;
			down = true;
		}
		else if (down && dy == 0) {
			down = false;
			up = true;
		}
		if (ytemp <= maxBoundsY && maxBoundsY != 0) {
			up = false;
			down = true;
		}
		else if (ytemp >= minBoundsY && minBoundsY != 0) {
			down = false;
			up = true;
		}
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 200) {
				flinching = false;
			}
		}
		// set animation
		if (flinching) {
			if (currentAction != FLINCH) {
				currentAction = FLINCH;
				animation.setFrames(sprites.get(FLINCH));
				animation.setDelay(100);
				width = 30;
			}
		}
		else if (up || down) {
			if (currentAction != FLYING) {
				currentAction = FLYING;
				animation.setFrames(sprites.get(FLYING));
				animation.setDelay(100);
				width = 30;
			}
		}
		
		animation.update();
	}
	
	public void draw(Graphics2D g) {
		
		setMapPosition();
		
		super.draw(g);
	}
}
