package Entity;

import TileMap.*;


import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import Game.GamePanel;
import GameState.GameState;
import GameState.Level1State;
import GameState.Level2State;

public class Player extends MapObject{
	
	// level stuff
	private GameState level;
	public static boolean clearStageMusic;
	
	// player stuff
	private int health;
	private int maxHealth;
	public boolean dead;
	private boolean flinching;
	private long flinchTime;
	private boolean knockBackRight;
	private boolean teleport;
	public boolean fellOffMap;
	private boolean victoryDance;
	
	// player attack
	private boolean jabbing;
	private int jabDamage;
	private int jabRange;
	public int resetJabSFX;
	
	// gliding
	private boolean gliding;
	
	
	// animations
	public static int count = 0;
	private ArrayList<BufferedImage[]> sprites = new ArrayList <BufferedImage[]>();
	private final int [] numFrames = {
			2, 10, 1, 2, 8, 4, 1, 2, 10, 62
	};

	
	// animation actions
	private static final int IDLE = 0;
	private static final int WALKING = 1;
	private static final int JUMPING = 2;
	private static final int FALLING = 3;
	private static final int GLIDING = 4;
	private static final int JABBING = 5;
	private static final int FLINCHING = 6;
	private static final int TELEPORT = 7;
	private static final int SWIMMING = 8;
	private static final int DANCE = 9;

	// emote animation
	private BufferedImage confused;
	private BufferedImage surprised;
	private int emote;
	public static final int NONE = 0;
	public static final int SURPRISED = 1;
	public static final int CONFUSED = 2;
	
	public Player (tileMap tm, GameState level) {
		super(tm);
		
		this.level = level;
		
		// size of tile sheet
		width = 30;
		height = 30;
		
		// size of player
		cwidth = 20;
		cheight = 20;
		
		// movement
		moveSpeed = 0.3;
		maxSpeed = 1.6;
		stopSpeed = 0.4;
		fallSpeed = 0.15;
		maxFallSpeed = 4.0;
		jumpStart = -4.8;
		stopJumpSpeed = 0.3;
		swimSpeed = 1;
		sinkSpeed = 0.7;
		
		facingRight = true;
		
		health = maxHealth = 5;
		
		jabDamage = 8;
		jabRange = 25;
		
		checkIsPlayer(true);
		
		// load sprites
		try {
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Player/player.png"));
			
			// load player sprites
			for (int i = 0; i < 10; i++) {
				BufferedImage[] bi = new BufferedImage[numFrames[i]];
				for (int j = 0; j < numFrames[i]; j++) {
					if (i != 5) {
						bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);
					}
					else {
						bi[j] = spritesheet.getSubimage(j * width * 2, i * height, width * 2, height);
					}
				}
				sprites.add(bi);
			}
			// emotes
			spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/HUD/Emotes.gif"));
			confused = spritesheet.getSubimage(
							0, 0, 14, 17
					);
			surprised = spritesheet.getSubimage(
							14, 0, 14, 17
						);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		// animation init
		animation = new Animation();
		currentAction = IDLE;
		animation.setFrames(sprites.get(IDLE));
		animation.setDelay(400);
		
		// emote init
		emote = NONE;
	}
	
	public int getHealth() { return health;}
	public int getMaxHealth() { return maxHealth;}
	
	public void setFacingRight(boolean b) {
		facingRight = true;
	}
	
	public void setJabbing(boolean b){ 
		jabbing = b; 
	}
	// b is needed because we cans top gliding any moment
	public void setGliding(boolean b) {
		gliding = b;
	}
	
	public Animation getAnimation() { return animation;}
	
	public void setEmote(int e) {
		emote = e;
	}
	
	public void setVictoryDance(boolean b) {
		victoryDance = b;
	}
	
	public void setSpeed(double num) {
		moveSpeed = maxSpeed = num;
	}
	
	public void setJumpSpeed(double num) {
		jumpStart = num;
	}
	
	public void setFallSpeed( double num) {
		fallSpeed = num;
	}
	
	public void setAction(int i) {
		if (i == 7 && !teleport) {
			teleport = true;
			animation.setFrames(sprites.get(i));
		}
		else if (i == 7){
			return;
		}
		else {
			animation.setFrames(sprites.get(i));
		}
	}
	
	public void stop() {
		left = right = up = down = jumping = jabbing = gliding = false;
		dy = 0;
	}
	
	public void checkAttack(ArrayList<Enemy> enemies) {
		
		// loop through enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			//e.setFlinch(false);
			if (jabbing && !intersects(e)) {
				if (e.isBoss) jabRange = 37;
				else jabRange = 25;
				if (facingRight) {
					if ((e.getx() - e.getCWidth() / 2) < (x + jabRange) && (e.getx() + e.getCWidth() / 2) > (x + jabRange) && (e.gety() + e.getCHeight() / 2) > y  && (e.gety() - e.getCHeight() / 2) < y) {
						if (!e.invincibility) {
							e.hit(jabDamage);
						}
					}
				}
				else {
					if ((e.getx() - e.getCWidth() / 2) < (x - jabRange) && (e.getx() + e.getCWidth() / 2) > (x - jabRange) && (e.gety() + e.getCHeight() / 2) > y  && (e.gety() - e.getCHeight() / 2) < y) {
						if (!e.invincibility) {
							e.hit(jabDamage);
						}
					}
				}
				
			}
			// check enemy collision
			if (intersects(e)) {
				hit(e.getDamage());
			}
		}
		
	}
	
	public void checkPlat(ArrayList<FerrisWheels> wheels) {
		for (int i = 0; i < wheels.size(); i ++) {
			for (int j = 0; j < wheels.get(i).getWheel().size(); j++) {
				boolean exit = false;
				if (intersects(wheels.get(i).getWheel().get(j))){
					if (dy < 0 && !hasLandedOnce && y >=  wheels.get(i).getWheel().get(j).y + wheels.get(i).getWheel().get(j).cheight / 2) {
						dy = 0;
						ytemp = wheels.get(i).getWheel().get(j).y + (wheels.get(i).getWheel().get(j).cheight - 0.5);
					}
					else if (dy >= 0 && y <= wheels.get(i).getWheel().get(j).y + wheels.get(i).getWheel().get(j).cheight / 2) {
						hasLandedOnce = true;
						dy = 0;
						falling = false;
						ytemp = wheels.get(i).getWheel().get(j).y - (wheels.get(i).getWheel().get(j).cheight  + 0.3);
					}
				}
				else {
					hasLandedOnce = false;
				}
			}
		}
	}
	
	public void hit (int damage) {
		if (flinching) return;
		health -= damage;
		if (health < 0) health = 0;
		if (health == 0) dead = true;
		flinching = true;
		flinchTime = System.nanoTime();
	}
	
	public void tpToCheckPoint() {
		int minDist = Math.abs((int) (level.checkPoints[0].x - x));
		int tpX = level.checkPoints[0].x;
		int tpY = level.checkPoints[0].y;
		for (int i = 0; i < level.checkPoints.length; i++) {
			if (level.checkPoints[i].x > x) continue;
			int temp = Math.abs((int) (level.checkPoints[i].x - x));
			if (minDist > temp) {
				minDist = temp;
				tpX = level.checkPoints[i].x;
				tpY = level.checkPoints[i].y;
			}
		}
		setPosition(tpX, tpY);
	}
	
	
	
	private void getNextPosition() {

		// player knockback
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTime) / 1000000;
			if (elapsed < 300) {
				left = false;
				right = false;
				if (knockBackRight) {
					dx = 1.5;
				} else {
					dx = -1.5;
				}
			}
		}
		// movement
		if (left) {
			dx -= moveSpeed;
			if (dx < -maxSpeed) {
				dx = -maxSpeed;
			}
			knockBackRight = true;
			if (swimming)
				dx = -swimSpeed;
		} else if (right) {
			dx += moveSpeed;
			if (dx > maxSpeed) {
				dx = maxSpeed;
			}
			knockBackRight = false;
			if (swimming)
				dx = swimSpeed;
		} else {
			if (dx > 0) {
				dx -= stopSpeed;
				if (dx < 0) {
					dx = 0;
				}
			} else if (dx < 0) {
				dx += stopSpeed;
				if (dx > 0) {
					dx = 0;
				}
			}
		}

		// cannot attack while moving unless in air
		if ((currentAction == JABBING) && !(jumping || falling)) {
			dx = 0;
		}
		
		// jumping
		if (jumping && !falling && !flinching) {
			if (!swimming) {
				falling = true;
				dy = jumpStart;
			}
			if (flinching) {
				dy = 0;
			}	
		}
		if (falling) {
			// sinking constant speed
			if (swimming) {
				if (finishDiving) dy = sinkSpeed;
				else {
					if (dy <= 0) {
						finishDiving = true;
					}
					else {
						dy -= fallSpeed;
						jumping = false;
					}
				}
			}
			else if (dy > 0 && gliding) {
				dy += fallSpeed * 0.1;
			} else {
				dy += fallSpeed;
			}
			
			if (dy > 0 && !swimming) jumping = false;
			
			// makes it so player can jump higher depending on how long they hold the button
			if (dy < 0 && !jumping && !swimming) {
				dy += stopJumpSpeed;
				jumping = true;
			}
			if (dy > maxFallSpeed) dy = maxFallSpeed;
		}
		// swimming upwards
		if (jumping && swimming) {
			dy  = -swimSpeed;
		}
	}

	public void update() {
		
		// update position
		getNextPosition();
		if (checkIfOffMap()) {
			health--;
			if (health <= 0) dead = true;
			else tpToCheckPoint();
		}
		checkTileMapCollision();
		if (level.level == 2) checkPlat(Level2State.wheels);
		setPosition(xtemp, ytemp);

		// check done flinching
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTime) / 1000000;
			if (elapsed > 1000) {
				count = 0;
				flinching = false;
			}
		}

		// reset gliding animation
		if ((dy < 0) && count > 0) count = 0;
		
		// set animation
		if (victoryDance) {
			if (currentAction != DANCE) {
				currentAction = DANCE;
				animation.setFrames(sprites.get(DANCE));
				animation.setDelay(400);
				width = 30;
			}
		}
		else if (jabbing) {
			if (resetJabSFX % 10 == 0) {
			}
			if (currentAction != JABBING) {
				currentAction = JABBING;
				animation.setFrames(sprites.get(JABBING));
				animation.setDelay(50);
				width = 60;
			}
			resetJabSFX ++;
		}
		else if (swimming && !wasSwimming) {
			if (swimming && currentAction != SWIMMING) {
				currentAction = SWIMMING;
				animation.setFrames(sprites.get(SWIMMING));
				animation.setDelay(50);
				width = 30;
			}
		}
		else if (dy > 0) {
			if (gliding) {
				currentAction = GLIDING;
				if (count == 0) animation.setFrames(sprites.get(GLIDING));
				else{
					animation.setDelay(100);
				}
				width = 30;
				count ++;
			}
			else if (currentAction != FALLING) {
				currentAction = FALLING;
				animation.setFrames(sprites.get(FALLING));
				animation.setDelay(100);
				width = 30;
			}
		}
		else if (dy < 0) {
			if (currentAction != JUMPING) {
				currentAction = JUMPING;
				animation.setFrames(sprites.get(JUMPING));
				animation.setDelay(-1);
				width = 30;
			}
			
		}
		else if (left || right) {
			if (currentAction != WALKING) {
				currentAction = WALKING;
				animation.setFrames(sprites.get(WALKING));
				animation.setDelay(40);
				width = 30;
			}
		}
		else if (teleport) {
			if (currentAction != TELEPORT) {
				currentAction = TELEPORT;
				animation.setDelay(200);
				width = 30;
			}
		}
		else {
			if (currentAction != IDLE) {
				currentAction =  IDLE;
				animation.setFrames(sprites.get(IDLE));
				animation.setDelay(1000);
				width = 30;
			}
		}
		
		animation.update();
		
		// set direction
		if (currentAction != JABBING) {
			if (right) facingRight = true;
			if (left) facingRight = false;
		}
	}
	
	public void draw(Graphics2D g) {
		
		setMapPosition();
		
		// draw emote
		if(emote == CONFUSED) {
			g.drawImage(confused, (int)(x + xmap - cwidth / 2), (int)(y + ymap - 30), null);
		}
		else if(emote == SURPRISED) {
			g.drawImage(surprised, (int)(x + xmap - cwidth / 2), (int)(y + ymap - 30), null);
		}
		// draw flinching
		if (flinching) {
			currentAction = FLINCHING;
			width = 30;
			animation.setFrames(sprites.get(FLINCHING));
			animation.setDelay(-1);
			long elapsed = (System.nanoTime() - flinchTime) / 1000000;
			if (elapsed / 100 % 2 == 0) {
				return;
			}
		}
		
		
		// draw player
		super.draw(g);
	}
}
