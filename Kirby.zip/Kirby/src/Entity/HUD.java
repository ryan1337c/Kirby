package Entity;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import java.awt.*;

public class HUD {

	private Player player;
	
	private BufferedImage image;
	private Font font;
	
	public HUD (Player player) {
		this.player = player;
		
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/Resources/HUD/newHud.gif"));
			font = new Font ("Arial", Font.PLAIN, 14);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D g) {
		for (int i = 0; i < player.getHealth(); i++) {
			g.drawImage(image, i * 20, 0, null);
		}
	}
	
	
}
