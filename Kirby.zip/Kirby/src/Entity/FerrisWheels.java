package Entity;

import java.awt.Graphics2D;
import java.util.ArrayList;

import GameState.GameState;
import TileMap.tileMap;


public class FerrisWheels extends MapObject{

	private ArrayList<Wheel> wheels;
	protected int xPos, yPos;
	
	public FerrisWheels(tileMap tm) {
		super(tm);
		
		wheels = new ArrayList<Wheel>();
		// creates 4 wheels
		wheels.add(new Wheel(tm));
		wheels.add(new Wheel(tm));
		wheels.add(new Wheel(tm));
		wheels.add(new Wheel(tm));
	}
	
	public void init() {
		wheels.get(0).init(xPos, yPos, 0);
		wheels.get(1).init(xPos, yPos, Math.PI /2);
		wheels.get(2).init(xPos, yPos, Math.PI);
		wheels.get(3).init(xPos, yPos, (3 * Math.PI) / 2);
	}
	
	public void setInitialPos(int x, int y) {
		xPos = x;
		yPos = y;
	}
	
	public void update() {
		for (int i = 0; i < wheels.size(); i++) {
			wheels.get(i).update();
		}
	}
	
	public ArrayList<Wheel> getWheel() {
		return wheels;
	}
	
	public void draw(Graphics2D g) {
		for (int i = 0; i < wheels.size(); i++) {
			wheels.get(i).draw(g);
		}
	}
}
