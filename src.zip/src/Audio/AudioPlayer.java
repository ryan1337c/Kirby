package Audio;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class AudioPlayer {
	
	private String path;
	private static Clip clip;
	private static AudioInputStream sound;
	private String type;
	private static HashMap<String, Clip> clips;
	public static ArrayList <String> clipsRunning;
	
	
	public static void init() {
		clips = new HashMap <String, Clip>();
		clipsRunning = new ArrayList<String>();
	}
	
	public static void load(String type, String music) {
		Clip clip;
		// setting audio
		try {
			AudioInputStream sound = AudioSystem.getAudioInputStream(AudioPlayer.class.getResourceAsStream(music));
			clip = AudioSystem.getClip();
			clip.open(sound);
			clips.put(type, clip);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void play(String s) {
		Clip c = clips.get(s);
		if (c == null) return;
		if (c.isRunning()) c.stop();
		c.setFramePosition(0);
		c.start();
		
	}
	
	public static void stop(String s) {
		if (clips.get(s) == null) return;
		if (clips.get(s).isRunning()) {
			clips.get(s).stop();
		}
	}
	
	public static void resume (String s) {
		if (clips.get(s).isRunning()) return;
		clips.get(s).start();
	}
	
	public static void loop(String s) {
		clips.get(s).loop(Clip.LOOP_CONTINUOUSLY);
	}
	
	public static void close(String s) {
		stop(s);
		clips.get(s).close();
	}
	
	// stops all running clips
	public static void stopAll() {
		for (int i = 0; i < clipsRunning.size(); i++) {
			stop(clipsRunning.get(i));
		}
	}
	
	public static void closeAll() {
		for (int i = 0; i < clipsRunning.size(); i++) {
			close(clipsRunning.get(i));
		}
	}
	
	public static void addClipsRunning(String s) {
		if (clipsRunning.contains(clips.get(s))) return;
		else clipsRunning.add(s);
	}
	
	public static void resumeAll() {
		for (int i = 0; i < clipsRunning.size(); i++) {
			resume(clipsRunning.get(i));
		}
	}
	
}
