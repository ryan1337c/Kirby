package GameState;

import java.awt.*;


import java.awt.event.KeyEvent;

import TileMap.Background;
import Audio.AudioPlayer;


public class MenuState extends GameState {
	
	private Background bg;
	public AudioPlayer audio;
	
	// features in the game
		private String[] options = {"Start", "Help", "Quit"};
		private Color titleColor;
		private Font titleFont;
		private Font font;
		private int currentChoice = 0;
		
	
	public MenuState (GameStateManager gsm) {
		this.gsm = gsm;
		
		try {
			bg = new Background ("/Resources/Backgrounds/menubg.gif", 1, 1);
			bg.setVector(-0.1, 0);
			titleColor = new Color (255,105,180);
			titleFont = new Font ("Century Gothic", Font.PLAIN, 28);
			font = new Font ("Arial", Font.PLAIN, 12);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		init();
	}
	
	public void init() {
		AudioPlayer.load("menu", "/Resources/Audio/MenuMusic.wav");
		AudioPlayer.play("menu");
		AudioPlayer.loop("menu");
		}
	
	public void update() {
		bg.update();
	}
	
	public void draw(Graphics2D g) {
		
		// draw bg
		bg.draw(g);
		
		// draw title
		g.setColor(titleColor);
		g.setFont(titleFont);
		g.drawString("Kirby's", 120, 70);
		g.drawString("Adventure", 90, 100);
		
		//draw menu options
		g.setFont(font);
		for (int i=0; i< options.length; i++) {
			if (i == currentChoice) {
				g.setColor(Color.BLACK);
			}
			else {
				g.setColor(Color.RED);
			}
			g.drawString(options[i], 145, 140 + i * 15);
		}
	}
	
	private void select() {
		if (currentChoice == 0) {
			// start
			gsm.setState(1);
			AudioPlayer.close("menu");
		}
		if (currentChoice == 1) {
			// help
			
		}
		if (currentChoice == 2) {
			// quit
			System.exit(0);
		}
	}
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select();
		}
		if (k == KeyEvent.VK_UP) {
			currentChoice--;
			if (currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if (k == KeyEvent.VK_DOWN) {
			currentChoice++;
			if (currentChoice == options.length) {
				currentChoice = 0;
			}
		}
		
	}
	public void keyRealeased(int k) {
		
	}
	

}
