package Game;

import java.awt.*;

import java.awt.image.BufferedImage;
import javax.swing.JPanel;

import GameState.GameStateManager;

import java.awt.event.*;

public class GamePanel extends JPanel implements Runnable, KeyListener{

	// dimensions
	public static final int WIDTH = 320;
	public static final int HEIGHT = 240;
	public static final int SCALE = 4;
	
	// game Thread
	private Thread thread;
	private boolean running;
	private int FPS = 60;
	private long targetTime = 1000/FPS;

	// image and canvas
	private BufferedImage image;
	private Graphics2D g;
	
	// GameState
	private GameStateManager gsm;
	
	public GamePanel () {
		super();
		setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
		setFocusable(true);
		requestFocus();
	}
	
	public void addNotify() {
		super.addNotify();
		if (thread == null) {
			thread = new Thread(this);
			addKeyListener(this);
			thread.start();
		}
	}

	@Override
	public void run() {
		init();
		
		long start;
		long elasped;
		long wait;
		
		// game running
		while (running) {
			start = System.nanoTime();
			
			update();
			draw();
			drawToScreen();
			
			elasped = System.nanoTime() - start;
			wait = targetTime - elasped / 1000000;
			
			try {
				if (wait < 0) {
					wait = 5;
				}
				// delays execution by the wait time 
				Thread.sleep(wait);
			}
			catch (Exception e) {
				// prints out error instead of showing a black screen when something goes wrong
				e.printStackTrace();
			}
			
		}
		
	}
	
	private void init() {
		image = new BufferedImage(WIDTH , HEIGHT , BufferedImage.TYPE_INT_RGB);
		g = (Graphics2D) image.getGraphics();
		running = true;
		gsm = new GameStateManager();
		
	}
	
	private void update() {
		gsm.update();
		
	}
	
	private void draw() {
		gsm.draw(g);
	}
	private void drawToScreen() {
		Graphics g2 = getGraphics();
		g2.drawImage(image, 0, 0, WIDTH * SCALE, HEIGHT * SCALE, null);
		g2.dispose();
		
	}
	
	
	@Override
	public void keyPressed(KeyEvent arg0) {
		try {
			gsm.keyPressed(arg0.getKeyCode());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		try {
			gsm.keyReleased(arg0.getKeyCode());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
}
