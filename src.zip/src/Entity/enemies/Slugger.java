package Entity.enemies;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import Entity.Animation;
import Entity.Enemy;
import TileMap.*;
import java.awt.Graphics2D;
public class Slugger extends Enemy{
	
	private BufferedImage []sprites;
	
	public Slugger (tileMap tm) {
		super(tm);
		
		// enemy stuff
		moveSpeed = 0.3;
		maxSpeed = 0.3;
		
		fallSpeed = 0.2;
		maxFallSpeed = 10.0;
		
		width = 30;
		height =  30;
		cwidth = cheight = 20;
		
		
		health = maxHealth = 10;
		damage = 1;
		
		try {
			sprites = new BufferedImage[2];
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Resources/Sprites/Enemies/slugger.gif"));
			for (int i = 0; i < sprites.length; i++) {
				sprites[i] = spritesheet.getSubimage(width * i, 0, width, height);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		animation = new Animation();
		animation.setFrames(sprites);
		animation.setDelay(300);

		right = true;
		facingRight = true;
	}
	
	public void getNextPosition() {
		// movement
		if (left) {
			dx -= moveSpeed;
			if (dx < -maxSpeed) {
				dx = -maxSpeed;
			}
		}
		else if (right) {
			dx += moveSpeed;
			if (dx > maxSpeed) {
				dx = maxSpeed;
			}
		}
		
		if (falling) {
			dy += moveSpeed;
		}
	}
	
	public void update() {
		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);

		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 200) {
				flinching = false;
			}
		}
		// if it hits a wall
		if (right && dx == 0) {
			right = false;
			left = true;
			facingRight = false;
		} else if (left && dx == 0) {
			left = false;
			right = true;
			facingRight = true;
		}

		// set animation
		animation.update();

	}
	
	public void draw (Graphics2D g) {
		setMapPosition();
		
		// check flinching
		if (flinching) {
			return;
		}
		super.draw(g);
	}

}
